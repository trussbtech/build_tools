# Blue Shield of CA Jenkins shared Library

This repository contains Jenkins Shared/Global Library with Unit tests.

## Why we need to Pipeline?
Building continuous delivery pipelines and similarly complex tasks in Jenkins using freestyle projects and traditional plugins can be awkward. You need to mix Parameterized Trigger, Copy Artifact, Promoted Builds, Conditional Build Step, and more just to express what should be a simple script. The Pipeline plugin (formerly known as Workflow) suite attempts to make it possible to directly write that script, what people often call a pipeline, while integrating with Jenkins features like agents and publishers.

###Current Build health of source code:

[![Build Status](https://castro-jenkins-stage.dev.bscal.local/buildStatus/icon?job=Jenkins/scrmauto)](https://castro-jenkins-stage.dev.bscal.local/job/Jenkins/job/scrmauto/)
## Features

* **Maven** for dependency management and test configuration (using *maven-resources*, *gmavenplus* and *surefire* plugin )
* IDE support for IntelliJ (Project detection + Auto-Completion)
* Unit tests with JenkinsPipelineUnit 


## Testing

Using Jenkins and writing pipeline-as-code is very powerful but can get pretty complex.
To speed up the development cycle this uses [JenkinsPipelineUnit](https://github.com/jenkinsci/JenkinsPipelineUnit), 
which lets you write unit tests on the configuration and conditional logic of the pipeline code, by providing a mock execution of the pipeline. You can mock built-in Jenkins commands, job configurations, see the stacktrace of the whole execution and even track regressions.

Run the tests with the following command:
```
mvn clean test
```
## Jenkins Pre-requisites

Install below plugins
* [Pipeline Utility steps](https://plugins.jenkins.io/pipeline-utility-steps)
  - [click here for more info](https://jenkins.io/doc/pipeline/steps/pipeline-utility-steps/)


## Development setup
* Install JDK
* Install mvn
* Install IntelliJ CE

## Some useful links

* https://jenkins.io/doc/book/pipeline/shared-libraries/
* https://www.cloudbees.com/blog/top-10-best-practices-jenkins-pipeline-plugin
* https://github.com/jenkinsci/JenkinsPipelineUnit
* https://github.com/jenkinsci/pipeline-plugin/blob/master/COMPATIBILITY.md
 
