import jenkins.pipeline.libs.BasePipelineTest
import org.junit.Test

class ConstansTest extends BasePipelineTest{

    @Test
    void validateConstant() {
        Class script = loadScript("src//bsc//scrmauto//jenkins//pipeline//Constants.groovy")
        GroovyObject scriptO = script.newInstance()
        binding.setVariable('git_Credentials', '79d0108a-9220-45b8-a42d-419ec50693c1')
        assert binding.getVariable('git_Credentials') == scriptO.git_credentials

        binding.setVariable('artifactory_npm_repo', 'http://uapp958n:8081/artifactory/api/npm/registry.npmjs.org/')
        assert binding.getVariable('artifactory_npm_repo') == scriptO.artifactory_npm_repo

    }

}

/*
import spock.lang.Specification

//artifactory_npm_repo
class ConstansTest extends Specification {

 def testfun(){
 
 	given:
 	    String expectedGitCredentials = '79d0108a-9220-45b8-a42d-419ec50693c1'
     when:
        def instConstants = new Constants()
        //def expectedGitCredentials = '79d0108a-9220-45b8-a42d-419ec50693c12'
        def retValGitCredentials = instConstants.git_credentials
        
        //assert expectedGitCredentials == retValGitCredentials
     then:
         expectedGitCredentials == retValGitCredentials
     
 
 }

}
*/