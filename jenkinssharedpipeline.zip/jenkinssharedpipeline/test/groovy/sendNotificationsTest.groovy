import jenkins.pipeline.libs.BasePipelineTest
import org.junit.Test

class sendNotificationsTest extends BasePipelineTest{


    @Test
    void sendemail() {

        Class script = loadScript("src//bsc//scrmauto//jenkins//pipeline//sendNotifications.groovy")

        GroovyObject scriptO = script.newInstance()
        //scriptO.notifypost()

    }
}
