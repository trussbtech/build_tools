import jenkins.pipeline.libs.BasePipelineTest
import org.junit.Ignore
import org.junit.Test

class GitUtilsTest extends BasePipelineTest{


    private boolean retInsideWorkTreeValidation = false
    private String retCommitId

    //@Test
    boolean insideWorkTreeValidation() {
        //def instGitUtils = getInstance()
        Class script = loadScript("src\\bsc\\scrmauto\\jenkins\\pipeline\\GitUtils.groovy")
        GroovyObject scriptO = script.newInstance()
        retInsideWorkTreeValidation = scriptO.insideWorkTree()
        retInsideWorkTreeValidation
    }

    //@Test
    String getGitCommitIdValidation() {
        //def instGitUtils = getInstance()
        Class script = loadScript("src\\bsc\\scrmauto\\jenkins\\pipeline\\GitUtils.groovy")
        GroovyObject scriptO = script.newInstance()
        retCommitId = scriptO.getGitCommitId()
        retCommitId
    }

    @Ignore
    @Test
    void getGitCommitIdorNullValidation() {

        if (insideWorkTreeValidation()) {
            retCommitId = getGitCommitIdValidation()
            assert retCommitId == "24pw6234abc014a"

        } else {
            //assertNull null
        }

    }

    void testGetChangelist() {


    }


}

