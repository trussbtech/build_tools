import org.junit.Ignore
import org.junit.Test

import jenkins.pipeline.libs.BasePipelineTest

class CommonPipelineStepsTest extends BasePipelineTest{


    def isWorkspaceClean = { givenDir ->
        def dir = new File(givenDir)
        dir.exists() && dir.directory && (dir.list() as List).empty
    }

    @Ignore
    @Test
    void cleanWorkspaceValidation() {

        def MOCK_WORKSPACE_DIR='test\\workspace\\'

        new File('test\\workspace\\target\\src').mkdirs()


        binding.setVariable('WORKSPACE', MOCK_WORKSPACE_DIR)

        def getWORKSPACE =  binding.getVariable('WORKSPACE')

        Class script = loadScript("src\\bsc\\scrmauto\\jenkins\\pipeline\\CommonPipelineSteps.groovy")

        GroovyObject scriptO = script.newInstance()
        assert isWorkspaceClean(MOCK_WORKSPACE_DIR)

        //scriptO.CleanWorkspace()
        assertTrue isWorkspaceClean(MOCK_WORKSPACE_DIR)

    }
}
