/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */


import jenkins.pipeline.libs.BasePipelineTest
import org.junit.Ignore

class ParseCommonsVarsTest extends BasePipelineTest{

    private String gitURL = " github.com/IonicaBizau/BSC-APP1/application1/validityparser.git "


    @Ignore
    void appNameValidation() {

        Class script = loadScript("src//bsc//scrmauto//jenkins//pipeline//ParseCommonVars.groovy")
        GroovyObject scriptO = script.newInstance()
        binding.setVariable('gitURL', ' github.com/IonicaBizau/BSC-APP1/application1/validityparser.git ')
        assert scriptO.getAppname(gitURL) == "application1"
    }

    @Ignore
    void compNameValidation() {

        Class script = loadScript("src//bsc//scrmauto//jenkins//pipeline//ParseCommonVars.groovy")
        GroovyObject scriptO = script.newInstance()
        binding.setVariable('gitURL', ' github.com/IonicaBizau/BSC-APP1/application1/validityparser.git ')
        assert scriptO.getCompname(gitURL) == "validityparser"

    }

}


