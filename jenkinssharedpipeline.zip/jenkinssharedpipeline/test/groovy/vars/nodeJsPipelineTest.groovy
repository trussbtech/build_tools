

import com.lesfurets.jenkins.unit.BasePipelineTest
import org.codehaus.groovy.ast.Variable
import org.junit.Ignore
import org.junit.Before
import org.junit.Test



class nodeJsPipelineTest extends BasePipelineTest {

    Script scriptArtifactoryUtil

    def skipDefaultCheckoutdummy



    @Override
    @Before
    void setUp() throws Exception {
        super.setScriptRoots('.', 'vars')

        super.setUp()
        def scmBranch = "master"
        helper.registerAllowedMethod('env', [List, Closure], null)
        helper.registerAllowedMethod('pipeline', [Closure.class], null)
        helper.registerAllowedMethod('triggers', [Closure.class], null)
        helper.registerAllowedMethod('pollSCM', [String.class], null)
        helper.registerAllowedMethod('agent', [Closure.class], null)
        helper.registerAllowedMethod('label', [String.class], null)
        helper.registerAllowedMethod('options', [Closure.class], null)
        helper.registerAllowedMethod('skipDefaultCheckout',  [Object.class], null)
        helper.registerAllowedMethod('tools',  [Object.class], null)
        helper.registerAllowedMethod('jdk', [String.class], null)
        helper.registerAllowedMethod('stages', [Closure.class], null)
        helper.registerAllowedMethod('steps', [Closure.class], null)
        helper.registerAllowedMethod('deleteDir', [], null)
        helper.registerAllowedMethod("git", [Map.class], null)
        helper.registerAllowedMethod('script',  [Object.class], null)
        helper.registerAllowedMethod("echo", [String.class], null)

        def checkoutParameters = [:]

        helper.registerAllowedMethod("scm",  [Object.class, Map.class] , { scmProp ->
            //
            git_commit = scmProp.GIT_COMMIT
            git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
            gitbranch = scmProp.GIT_BRANCH
            gituri = scmProp.GIT_URL

        })

        helper.registerAllowedMethod("tool",  [Map] , null)
        helper.registerAllowedMethod("unzip",  [Map] , null)
        helper.registerAllowedMethod("zip",  [Map] , null)
        helper.registerAllowedMethod('post', [Closure.class], null)
        helper.registerAllowedMethod('always', [Closure.class], null)
        binding.setVariable('currentBuild', [result: 'SUCCESS'])
        helper.registerAllowedMethod("ArtifactoryUtils",  [Object.class] , null)
        binding.setVariable('WORKSPACE', '/tmp')
        binding.setVariable('scm', [:])
        helper.registerAllowedMethod("readProperties", [Map.class], null)
        binding.setVariable('env', [:])


    }

    @Ignore
    @Test
    void nodeJsMainTest(){

        Script scriptO = loadScript("vars\\nodeJsPipelinedeclarative.groovy")

        def body = {
            gituri = "ssh://git@uapp958n:7999/fad/findadoctor.git"
            nodejsVersion = "nodejs-6.11.4"
            buildenv = ["prod", "qa1", "stage"]

        }

        scriptO( body)
        printCallStack()

        assertThat(helper.callStack.findAll { call ->
            call.methodName == "sh"
        }.any { call ->
            callArgsToString(call).contains("zip")
        }).isTrue()
        assertJobStatusSuccess()

    }

}