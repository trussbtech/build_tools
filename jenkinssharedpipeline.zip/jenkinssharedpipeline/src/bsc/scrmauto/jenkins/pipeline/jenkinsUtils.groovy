/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */
package bsc.scrmauto.jenkins.pipeline

import com.cloudbees.groovy.cps.NonCPS
import hudson.tasks.test.AbstractTestResultAction

@NonCPS
def getTestSummary() {
    def testResultAction = currentBuild.rawBuild.getAction(AbstractTestResultAction.class)
    def summary = ""

    if (testResultAction != null) {
        def total = testResultAction.getTotalCount()
        def failed = testResultAction.getFailCount()
        def skipped = testResultAction.getSkipCount()

        summary = "Test results:\n\t"
        summary = summary + ("Passed: " + (total - failed - skipped))
        summary = summary + (", Failed: " + failed)
        summary = summary + (", Skipped: " + skipped)
    } else {
        summary = "No tests found"
    }
    return summary
}

def abortFirstbuild() {
    int buildnumber = currentBuild.number.toInteger()
    int firstbuildnum = 1

    if (buildnumber == firstbuildnum) {
        currentBuild.result = 'ABORTED'
        error('Stopping early to update componenet.properties file with correct version')
    }
}