package bsc.scrmauto.jenkins.pipeline

/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */

//Using pipeline utility steps plugin
/**
 *
 * @param filepath - path to properties file needed for building project in Jenkins
 */
def loadProperties(filepath) {
    properties = readProperties file: filepath
    //echo "Immediate one ${properties.repo}"
}
