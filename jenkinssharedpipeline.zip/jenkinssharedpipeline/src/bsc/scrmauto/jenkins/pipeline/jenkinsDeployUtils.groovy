#!/usr/bin/env groovy
package bsc.scrmauto.jenkins.pipeline

/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */

def triggerDeployJob(String jName = "", String envName = "", String rlsVer = "", boolean hold = false) {

    def prjkey
    def compname

    if (jName.contains("-")) {
        def (a, b, c, d) = jName.split("-")
        propfilename = a + "-" + b + "-" + envName + ".properties"
        prjkey = a
        compname = b
    } else if (jName.contains("/")){
        def (a, b, c, d) = jName.split("/")
        propfilename = a + "-" + d + "-" + envName + ".properties"
        prjkey = a
        compname = d
    } else {
        echo "JOB NAME is following standard convention"
    }

    //echo propfilename
    withCredentials([usernamePassword(credentialsId: 'jenkins-bitbucket-prod', passwordVariable: 'artipassword', usernameVariable: 'artiusername')]) {
        bat """
	    @echo off
		python %JENKINSAUTODEPLOY% -p "${prjkey}" -c "${compname}" -r "${rlsVer}" -e "${envName}"
		"""
    }

    if (fileExists(propfilename)) {
        properties = readProperties file: propfilename
        String arti = properties.Artifact
        String depEnv = properties.DEPLOY_ENV
        stage("Trigger: ${jName}") {

            build job: jName,
                    parameters: [
                            string(name: 'Artifact', value: arti),
                            string(name: 'DEPLOY_ENV', value: depEnv)
                    ],
                    quietPeriod: 2,
                    propagate: true,
                    wait: hold
        }
    } else {
        echo 'Skipping job to trigger'
    }

    /*build job: 'bor-HPXRBOReports42-deploy-npe',
                          parameters: [
                                string(name: 'Artifact', value: "bor-HPXRBOReports42-19.0301_pp1.42.zip"),
                                string(name: 'DEPLOY_ENV', value: "qa2")
                            ],
                            quietPeriod: 2, wait: true
                            */
}

