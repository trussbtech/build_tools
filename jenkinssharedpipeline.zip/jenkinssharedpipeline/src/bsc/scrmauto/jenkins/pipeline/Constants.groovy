package bsc.scrmauto.jenkins.pipeline

/**
 *** @author pdigum01
 * @Team IT-SCRM-Automation
 */
import groovy.transform.Field

@Field final String git_credentials = '79d0108a-9220-45b8-a42d-419ec50693c1'
@Field final String artifactory_npm_repo = 'http://uapp958n:8081/artifactory/api/npm/registry.npmjs.org/'
@Field final String artifactoryinstance = 'bsc-artifactory'
@Field final String utilantVersion = 'ant-1.7.1'
//@Field final String restapibburi = System.getenv("restapibburi")
@Field final String restapibburi = 'http://uapp958n:7990/rest/api/1.0/projects/'
@Field final String appCenterUserAPItoken = '410c360704910185408b3e2106fb301fb393bb89'
