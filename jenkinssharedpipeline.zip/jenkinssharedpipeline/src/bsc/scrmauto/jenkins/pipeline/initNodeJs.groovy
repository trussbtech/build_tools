#!/usr/bin/env groovy
package bsc.scrmauto.jenkins.pipeline

import org.apache.commons.lang.SystemUtils

//def antVersion = 'ant-1.7.1'
/**
 *
 * @return OS of current machine
 */
String whichOS() {
    if (SystemUtils.IS_OS_WINDOWS) {
        return "WINDOWS"
    } else if (SystemUtils.IS_OS_UNIX) {
        return "UNIX"
    }
}

/**
 * This method initializes NodeJS on the current Jenkins slave.
 * Needed for all NodeJS projects running on Jenkins
 */
def init() {
    if (whichOS() == "WINDOWS") {

    } else if (whichOS() == "UNIX") {
        sh '''
			cd ${WORKSPACE}
			echo copying ${BUILD_XML}
			cp ${BUILD_XML} .

			echo copying ${JENKINS_ARTIFACT_TEMPLATE_ZIP}
			cp ${JENKINS_ARTIFACT_TEMPLATE_ZIP} .
			
			echo $PATH
			npm --version
			node --version
			npm config set registry http://uapp958n:8081/artifactory/api/npm/registry.npmjs.org/
			npm install
			ng set --global warnings.versionMismatch=false
			ng version
		'''
    }
}