#!/usr/bin/env groovy

package bsc.scrmauto.jenkins.pipeline

import bsc.scrmauto.jenkins.pipeline.ParseCommonVars
import bsc.scrmauto.jenkins.pipeline.bitbucket.restclient

/**
 * This method uploads artifacts created by jenkins build job to Artifactory
 *
 * @param gituri Application git url
 * @param gitbranch Application git branch
 * @param jiraVersion Jira Fix Version for this build
 */
def Uploadartifact(String gituri, String gitbranch, String jiraVersion, String git_commit, String ZIP_TAG, String erm, def morebuildinfo = null) {

    def ParseCommonVars = new ParseCommonVars()
    def Constants = new Constants()
    def gitchangelist = this.env.BUILD_URL + "/changes"
    def artifactoryinstance = Constants.artifactoryinstance

    //GIT_COMMIT_HASH = GitUtils.getGitCommitIdOrNull()
    def server = Artifactory.server "${artifactoryinstance}"
    def appname = ParseCommonVars.getAppname(gituri)
    def compname = ParseCommonVars.getCompname(gituri)
    //def jiraVersion = "${config.jiraVersion}"
    //ZIP_TAG = appname + '-' + compname + '-' + "${jiraVersion}" + '.' + "${env.BUILD_ID}" + '.zip'
    echo "${ZIP_TAG}"

    if (fileExists("${ZIP_TAG}")) {
        currentBuild.description = "${ZIP_TAG}"
        currentBuild.displayName = '#' + "${jiraVersion}" + '.' + "${env.BUILD_ID}"
        def uploadSpec = """{
  					"files": [
    					{
      						"pattern": "${ZIP_TAG}",
      						"target": "bsc-central-ci/${appname}/${compname}/${jiraVersion}/${ZIP_TAG}",
							"props": "gituri=${gituri};jiraVersion=${jiraVersion};git_branch=${gitbranch};git_commit=${
            git_commit
        };gitchangelist=${gitchangelist};erm=${erm}"
    					}
 					]
				}"""

        def buildInfoPre = Artifactory.newBuildInfo()
        buildInfoPre.retention maxBuilds: 5, deleteBuildArtifacts: true
        buildInfoPre.env.capture = true
        buildInfoPre.env.filter.addExclude("*_pwd_*")
        def buildInfo = server.upload(uploadSpec, buildInfoPre)
        if (morebuildinfo) {
            buildInfo.append morebuildinfo
        }
        server.publishBuildInfo buildInfo
        def ermPropFile = "#ERM Properties file \n"
        ermPropFile += "\nArtifact=${ZIP_TAG}\n"
        writeFile file: "erm-" + jiraVersion + ".properties", text: ermPropFile
    } else {
        error("Missing ${ZIP_TAG} in workspace")
    }
}

/**
 * This method uploads Nuget package to Artifactory Nuget repository.
 *
 * @param nugetPackageName - as the name implies
 * @param appName - as the name implies
 * @param compName - the component name from the application
 * @param releaseVersion - the release #, i.e. 18.9.3
 */
def uploadNugetPackage(nugetPackageName, appName, compName, releaseVersion) {
    def nugetBinPath = "${NUGET_BIN_PATH}" + "\\NuGet"
    def bscNugetRepoPath = "${BSC_NUGET_REPO_PATH}"

    withCredentials([usernamePassword(credentialsId: 'artifactory', passwordVariable: 'artifactPassword', usernameVariable: 'artifactUser')]) {
        bat "${nugetBinPath}" + " push " + "${nugetPackageName}" + " " + "${artifactUser}:${artifactPassword}" + " -Source " + "${bscNugetRepoPath}" + "/" + "${appName}" + "/" + "${compName}" + "/" + "${releaseVersion}"
    }
}

def Uploadartifactmobile(String gituri, String gitbranch, String jiraVersion, String git_commit, String ZIP_TAG, String erm) {

    def ParseCommonVars = new ParseCommonVars()
    def Constants = new Constants()
    def gitchangelist = this.env.BUILD_URL + "/changes"
    def artifactoryinstance = Constants.artifactoryinstance

    //GIT_COMMIT_HASH = GitUtils.getGitCommitIdOrNull()
    def server = Artifactory.server "${artifactoryinstance}"
    def appname = ParseCommonVars.getAppname(gituri)
    def compname = ParseCommonVars.getCompname(gituri)
    def buildVersion = "${jiraVersion}" + '.' + "${env.BUILD_ID}"
    //def jiraVersion = "${config.jiraVersion}"
    //ZIP_TAG = appname + '-' + compname + '-' + "${jiraVersion}" + '.' + "${env.BUILD_ID}" + '.zip'
    echo "${ZIP_TAG}"

    if (fileExists("${ZIP_TAG}")) {
        currentBuild.description = "${ZIP_TAG}"
        currentBuild.displayName = '#' + "${buildVersion}"
        def uploadSpec = """{
  					"files": [
    					{
      						"pattern": "${ZIP_TAG}",
      						"target": "bsc-central-ci/${appname}/${compname}/${jiraVersion}/${ZIP_TAG}",
							"props": "gituri=${gituri};jiraVersion=${jiraVersion};git_branch=${gitbranch};git_commit=${git_commit};gitchangelist=${gitchangelist};erm=${erm}"
    					},
    					{
                            "pattern": "dist/du_full/*",
                            "target": "mobile/${jiraVersion}/${compname}/${buildVersion}/",
                            "flat": "false",
                            "recursive":"true",
                            "props": "gituri=${gituri};jiraVersion=${jiraVersion};git_branch=${gitbranch};git_commit=${git_commit};gitchangelist=${gitchangelist};erm=${erm}"
                        }
 					]
				}"""

        def buildInfoPre = Artifactory.newBuildInfo()
        buildInfoPre.retention maxBuilds: 3, deleteBuildArtifacts: true
        buildInfoPre.env.capture = true
        buildInfoPre.env.filter.addExclude("*_pwd_*")
        def buildInfo = server.upload(uploadSpec, buildInfoPre)
        server.publishBuildInfo buildInfo
        def ermPropFile = "#ERM Properties file \n"
        ermPropFile += "\nArtifact=${ZIP_TAG}\n"
        writeFile file: "erm-" + jiraVersion + ".properties", text: ermPropFile
    } else {
        error("Missing ${ZIP_TAG} in workspace")
    }
}

def mvnbuild(String mvnVersion, String pomPath, String mvnGoals) {

    def Constants = new Constants()
    def CommonPipelineSteps = new CommonPipelineSteps()


    if (mvnGoals.toLowerCase().contains('deploy')) {
        if (!env.CHANGE_ID) {
            CommonPipelineSteps.mvnbuild("${mvnVersion}", "${env.WORKSPACE}//${env.BRANCH_NAME}", "${mvnGoals}")
        } else {
            CommonPipelineSteps.mvnbuild("${mvnVersion}", "${env.WORKSPACE}//${env.BRANCH_NAME}", "clean install -B -V pmd:pmd")
        }
    } else{
        //def mvnbuildInfo = Artifactory.newBuildInfo()
        CommonPipelineSteps.mvnbuild("${mvnVersion}", "${env.WORKSPACE}//${env.BRANCH_NAME}", "${mvnGoals}")
        //server.publishBuildInfo buildInfo
        //return mvnbuildInfo
    }

    //rtMaven.resolver server: server, releaseRepo: 'public', snapshotRepo: 'public'
    //rtMaven.deployer server: server, releaseRepo: 'public', snapshotRepo: 'public'

}

def UploadqeTestReports(String gituri, String gitbranch, String jiraVersion, String testType, String git_commit, String envName, def morebuildinfo = null) {

    def ParseCommonVars = new ParseCommonVars()
    def Constants = new Constants()
    def gitchangelist = this.env.BUILD_URL + "/changes"
    def artifactoryinstance = Constants.artifactoryinstance
    def now = new Date()
    String time = now.format("yyyy-MM-dd-HH-mm", TimeZone.getTimeZone('PST'))

    //GIT_COMMIT_HASH = GitUtils.getGitCommitIdOrNull()
    def server = Artifactory.server "${artifactoryinstance}"
    def appname = ParseCommonVars.getAppname(gituri)
    def compname = ParseCommonVars.getCompname(gituri)
    //def buildVersion = "${jiraVersion}" + '.' + "${env.BUILD_ID}"
    //def jiraVersion = "${config.jiraVersion}"
    //ZIP_TAG = appname + '-' + compname + '-' + "${jiraVersion}" + '.' + "${env.BUILD_ID}" + '.zip'
    //echo "${ZIP_TAG}"

    //currentBuild.description = "${ZIP_TAG}"
    //currentBuild.displayName = '#' + "${buildVersion}"
    def uploadSpec = """{
  					"files": [
    					{
      						"pattern": "*-*-*-*-*.zip",
      						"target": "qes-test-results/${appname}/${compname}/${envName}/${testType}/${gitbranch}/",
							"props": "gituri=${gituri};testType=${testType};git_branch=${gitbranch};git_commit=${git_commit};gitchangelist=${gitchangelist};jiraVersion=${jiraVersion};environment=${envName}"
    					}
 					]
				}"""

    def buildInfoPre = Artifactory.newBuildInfo()
    buildInfoPre.retention maxBuilds: 30, deleteBuildArtifacts: true
    buildInfoPre.env.capture = true
    buildInfoPre.env.filter.addExclude("*_pwd_*")
    def buildInfo = server.upload(uploadSpec, buildInfoPre)
    if (morebuildinfo) {
        buildInfo.append morebuildinfo
    }
    server.publishBuildInfo buildInfo
}


def CheckIsThisProdFixVersion( String gituri, String jiraVersion) {
    def ParseCommonVars = new ParseCommonVars()
    def restclient = new restclient()
    def appname = ParseCommonVars.getAppname(gituri)
    def compname = ParseCommonVars.getCompname(gituri)

    artifactUri = "${env.ARTIFACTORY_URL}" + "/api/search/aql"
    //body = body='items.find( {"repo":"bsc-central-prod"},{"path":"mpo/MemberPortal/19.12.02"})'

    slash = "/"

    repo = "bsc-central-prod"
    repoParam = '"repo"' + " : "  + '"' + "${repo}" + '"'
    path = appname + slash + compname + slash + jiraVersion
    pathParam = '"path"' + " : " +  '"' + path + '"'
    body = "items.find( { ${repoParam} },{ ${pathParam} })"

    //println(body)
    //println(artifactUri)

    restclient.postRC( artifactUri , body )



}