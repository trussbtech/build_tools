#!/usr/bin/env groovy
package bsc.scrmauto.jenkins.pipeline

import bsc.scrmauto.jenkins.pipeline.Constants
import com.cloudbees.groovy.cps.NonCPS
import hudson.tasks.test.AbstractTestResultAction

class UtilsGlobals {
    static Constants = new Constants()
    static String utilantVersion = Constants.utilantVersion
}

def whichOS() {
    if (isUnix()) {
        //print "Unix...."
        def uname = sh (script: '#!/bin/sh -e\n'+ 'uname',returnStdout: true)
        if (uname.startsWith("Darwin")) {
            return "MAC"
        } else {
            return "UNIX"
        }
    } else {
        //echo "WINDOWS......"
        return "WINDOWS"
    }
}


//TODO-Pavan Explore to access Workspace path on node and perfrom read and write operations
//TODO-Pavan Exteranliaze zip and unzip from templates


/**
 * This method creates zip files of artifacts
 * @param DdestPar - destination where zip files get created into
 * @param DprefixPar (optional) -
 * @param DzipFileNamePar - Name of Zip file to be created
 * @param DsrcPar - Name of Destination folder
 * @param DexcludesPar - files/folders to be excluded from zip file
 */
def zip(String src, String zipFileName, String dest = ".", String exclude = "**/application.json") {
    def antVersion = UtilsGlobals.utilantVersion
    if (whichOS() == "WINDOWS") {
        bat "COPY %BUILD_XML% ."
        withEnv(["ANT_HOME=${tool antVersion}"]) {
            bat "%ANT_HOME%//bin//ant -file build.xml -DzipFileName=${zipFileName} -Dsrc=${src} -Ddest=${dest} \"-Dexcludes=${exclude}\" -Dprefix=\"\" zip"
        }

    } else {
        sh(returnStatus: true, script: "cp ${BUILD_XML} .")
        withEnv(["ANT_HOME=${tool antVersion}"]) {
            sh "$ANT_HOME/bin/ant -file build.xml -DzipFileName=${zipFileName} -Dsrc=${src} -Ddest=${dest} \"-Dexcludes=${exclude}\" -Dprefix=\"\" zip"
        }
    }
}

/**
 * This method creates copy files of artifacts
 * @param DdestPar - destination where zip files get created into
 * @param DprefixPar (optional) -
 * @param DzipFileNamePar - Name of Zip file to be created
 * @param DsrcPar - Name of Destination folder
 * @param DexcludesPar - files/folders to be excluded from zip file
 */
def copy(String src, String dest, String includes = "", String exclude = "") {
    def antVersion = UtilsGlobals.utilantVersion
    if (whichOS() == "WINDOWS") {
        bat "COPY %BUILD_XML% ."
        withEnv(["ANT_HOME=${tool antVersion}"]) {
            bat "%ANT_HOME%//bin//ant -file build.xml -Dsrc=${src} -Ddest=${dest} \"-Dincludes=${includes}\" \"-Dexcludes=${exclude}\" copy"
        }

    } else {
        sh(returnStatus: true, script: "cp ${BUILD_XML} .")
        withEnv(["ANT_HOME=${tool antVersion}"]) {
            sh "$ANT_HOME/bin/ant -file build.xml -Dsrc=${src} -Ddest=${dest} \"-Dincludes=${includes}\" \"-Dexcludes=${exclude}\" copy"
        }
    }
}

/**
 * This method creates flatcopy files of artifacts
 * @param DdestPar - destination where zip files get created into
 * @param DprefixPar (optional) -
 * @param DzipFileNamePar - Name of Zip file to be created
 * @param DsrcPar - Name of Destination folder
 * @param DexcludesPar - files/folders to be excluded from zip file
 */
def copyflat(String src, String dest, String includes = "", String exclude = "") {
    def antVersion = UtilsGlobals.utilantVersion
    if (whichOS() == "WINDOWS") {
        bat "COPY %BUILD_XML% ."
        withEnv(["ANT_HOME=${tool antVersion}"]) {
            bat "%ANT_HOME%//bin//ant -file build.xml -Dsrc=${src} -Ddest=${dest} -Dflatten=true \"-Dincludes=${includes}\" \"-Dexcludes=${exclude}\" copy"
        }

    } else {
        sh(returnStatus: true, script: "cp ${BUILD_XML} .")
        withEnv(["ANT_HOME=${tool antVersion}"]) {
            sh "$ANT_HOME/bin/ant -file build.xml -Dsrc=${src} -Ddest=${dest} -Dflatten=true \"-Dincludes=${includes}\" \"-Dexcludes=${exclude}\" copy"
        }
    }
}

/**
 *
 * @param DdestPar - Destination of unzipped files
 * @param DsrcPar - location of zip file
 * @return 0 or 1
 */
def unzip(String dist, String src) {
    def antVersion = UtilsGlobals.utilantVersion
    if (whichOS() == "WINDOWS") {
        bat "COPY %BUILD_XML% ."
        withEnv(["ANT_HOME=${tool antVersion}"]) {
            bat "%ANT_HOME%//bin//ant -file build.xml -Ddest=${dist} -Dsrc=${src} unzip"
        }

    } else {
        sh(returnStatus: true, script: "cp ${BUILD_XML} .")
        withEnv(["ANT_HOME=${tool antVersion}"]) {
            sh "$ANT_HOME/bin/ant -file build.xml -Ddest=${dist} -Dsrc=${src} unzip"
        }
    }
}


def getartifacttemplate() {
    if (whichOS() == "WINDOWS") {
        bat '''
            @echo off
            REM echo copying %JENKINS_ARTIFACT_TEMPLATE_ZIP%
            COPY %JENKINS_ARTIFACT_TEMPLATE_ZIP% .
            '''
    } else {
        sh '''
            #!/bin/sh
            #echo copying ${JENKINS_ARTIFACT_TEMPLATE_ZIP}
            cp ${JENKINS_ARTIFACT_TEMPLATE_ZIP} .
            '''
    }
    unzip("dist", "JenkinsArtifactTemplate.zip",)
}

/**
 *
 * @param token - search token
 * @param include - Search files (ant pattern is supported)
 * @param Value - replace value
 * @param src - file location recersive from workspace
 * @return 0 or 1
 */

def replace(String token, String includes, String value, String src = ".") {
    def antVersion = UtilsGlobals.utilantVersion
    if (whichOS() == "WINDOWS") {
        bat "COPY %BUILD_XML% ."
        // example : %ANT% -f build.xml -Dtoken=$UPDATENPEPASSWORD$ -Dincludes=env.bat -Dvalue="aGIpEcY1wBvhWRWLJ/dRfQ==" -Dsrc=temp\scripts\10.2.0 replace
        withEnv(["ANT_HOME=${tool antVersion}"]) {
            bat "%ANT_HOME%//bin//ant -file build.xml -Dtoken=$token -Dincludes=$includes -Dvalue=$value -Dsrc=$src replace"
        }

    } else if (whichOS() == "UNIX") {
        sh(returnStatus: true, script: "cp ${BUILD_XML} .")
        withEnv(["ANT_HOME=${tool antVersion}"]) {
            sh "$ANT_HOME/bin/ant -file build.xml -Dtoken=$token -Dincludes=$includes -Dvalue=$value -Dsrc=$src replace"
        }
    }
}



/**
 *
 * @param match - match the value to search
 * @param match - replace value
 * @param file - file location recersive from workspace
 * @return 0 or 1
 */

def replaceregexp (String match, String replace, String file) {
    def antVersion = UtilsGlobals.utilantVersion
    if (whichOS() == "WINDOWS") {
        bat "COPY %BUILD_XML% ."
        // example : %ANT% -f build.xml -Dtoken=$UPDATENPEPASSWORD$ -Dincludes=env.bat -Dvalue="aGIpEcY1wBvhWRWLJ/dRfQ==" -Dsrc=temp\scripts\10.2.0 replace
        withEnv(["ANT_HOME=${tool antVersion}"]) {
             bat "%ANT_HOME%//bin//ant -file build.xml  \"-Dsrc=$file\" \"-Dmatch=<profileName>(.*?)\" \"-Dreplace=<profileName>opstest</profileName>\" \"-Dflags=g\" replaceregexp"
            //bat "%ANT_HOME%//bin//ant -file build.xml -Dmatch=${match} -Dreplace=${replace} -Dsrc=$file replaceregexp"
        }

    } else if (whichOS() == "UNIX") {
        sh(returnStatus: true, script: "cp ${BUILD_XML} .")
        withEnv(["ANT_HOME=${tool antVersion}"]) {
            sh "$ANT_HOME/bin/ant -file build.xml -Dmatch=${match} -Dreplace=${replace} -Dsrc=$file replaceregexp"
        }
    }
}


/**
 * This method prints out the environment variables
 */
def printEnv() {
    if (whichOS() == "WINDOWS") {
        bat 'set > env.txt'
        for (String i : readFile('env.txt').split("\r?\n")) {
            println i
        }
    } else {
        sh 'env > env.txt'
        readFile('env.txt').split("\r?\n").each {
            println it
        }
    }
}

/**
 * This function reads a given text file, and replace the specified text in the file content with a new text value.
 * @param fileName - name of the file.  Full path may be included with filename.  If no path included, the current directory is used.
 * @param searchString - the text string to be searched in the file content.
 * @param replaceString - the text string to be replaced.
 * NOTE: special characters may be escaped with the \ character in the search / replace string.
 */
def replaceFileContent(fileName, searchString, replaceString) {
    def inFile = readFile file: fileName
    inFile = inFile.replace(searchString, replaceString)
    writeFile file: fileName, text: inFile
}

@NonCPS
def readfoldertolist(String path) {
    def folderslist = []
    def folders = bat(returnStdout: true, script: """
                                                    @echo off
                                                    dir ${path} /b /ad
                                                  """).toString().trim().split("\\r?\\n\\r")
    //folderslist = folders.replaceAll("\n", ",").split('\n')

    return folders
}


def readDir(String path) {
    bat """
            @echo off
            dir "${path}" /b /ad > readDir
        """
    def folders = []
    folders = readFile("readDir").split("\\r?\\n").sort()

    bat """
            @echo off
            del /f readDir
        """
    //folderslist = folder
    //print folders.size()
    return folders
    //return folders.toString().replace(" ", "")
}


@NonCPS
def getBuildUser() {

    causeType = currentBuild.rawBuild.getCause(Cause.UserIdCause)
    echo "${causeType}"
    causeSpecificType = causeType.getClass()
    echo "${causeSpecificType}"

    //usrname = causeType.getUserName()
    //echo "${usrname}"

    if (causeSpecificType == hudson.model.Cause$UserIdCause) {
        username = currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserName()
        return username
    }
    else {
        return ("jenkins")
    }
    causeType = null

}

def autocommentJira(){

    echo "autoCommentJira....."
    echo AUTO_COMMENT_JIRA_UTIL
    instanceURL = this.env.JENKINS_URL
    jobURL = this.env.JOB_URL
    echo jobURL
    echo instanceURL


    if(whichOS() == "UNIX") {
        sh """

         /usr/local/bin/python2.7  "${AUTO_COMMENT_JIRA_UTIL}"  -jobURL "${jobURL}"
        """
    } else if (whichOS() == "WINDOWS"){
        echo "runnning bat..."
        bat """
        python %AUTO_COMMENT_JIRA_UTIL%   -joburl "${jobURL}"
        """
    }

}



@NonCPS
def InsertJenkinsDB(String pipelinename, String compname, String appname, String ZIP_TAG, String jiraVersion, String jiraProjectKey, String git_commit, String gitbranch, String erm=null) {

    ZIP = ".zip"
    DOT ='.'
    //def dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm")
    def date = new Date().format("yyyy-MM-dd-HH-mm-ss", TimeZone.getTimeZone('PST'))
    def buildcause
    def jobType
    //println date.format("yyyy-MM-dd-HH-mm", TimeZone.getTimeZone('PST'))
    //echo(dateFormat.format(date), timeZone)

    currentBuild.result = currentBuild.currentResult

    causeType = currentBuild.rawBuild.getCause(Cause.UserIdCause)
    causeSpecificType = causeType.getClass()

    //usrname = causeType.getUserName()
    //echo "${usrname}"

    if (causeSpecificType == hudson.model.Cause$UserIdCause) {
        buildcause = currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserName()

    }
    else {
        buildcause = "jenkins"
    }
    causeType = null

    buildNum = this.env.BUILD_NUMBER
    envName = this.env.Environment
    testType = this.env.TestType


    //artifact = ZIP_TAG + ZIP
    artifact = ZIP_TAG.take(ZIP_TAG.lastIndexOf(DOT))
    //date , compname
    String jobName = this.env.JOB_NAME
    String buildURL = this.env.BUILD_URL
    //println buildURL
    String deploy_env = this.env.DEPLOY_ENV

    if(jobName.toUpperCase().contains("BUILD"))
        jobType = "BUILD"
    else if (jobName.toUpperCase().contains("DEPLOY"))
        jobType = "DEPLOY"
    else if (jobName.toUpperCase().contains("QETEST"))
        jobType = "QETEST"
    else {
        echo "WARNING: Skipping to insert to DB, as this job was not following standard naming convention"
        return
    }


    if("${gitbranch}".startsWith("PR-")) {
        artifact = "UNKNOWN"
        appname = jobName.split('/')[0]
        compname = jobName.split('/')[2]
        echo appname
        echo compname
    }



    //print "${currentBuild.startTimeInMillis}"
    //print "${currentBuild.durationString}"
    def startTime = new Date(currentBuild.startTimeInMillis).format("yyyy-MM-dd-HH-mm-ss", TimeZone.getTimeZone('PST'))

    def TestCountTotal
    def TestCountFailed
    def TestCountSkipped
    def Tests
    //writeFile file: 'junitreport.txt', text:"\r\n"

    def testResultAction = currentBuild.rawBuild.getAction(AbstractTestResultAction.class)
    if (testResultAction != null) {
        TestCountTotal = testResultAction.getTotalCount()
        TestCountFailed = testResultAction.getFailCount()
        TestCountSkipped = testResultAction.getSkipCount()
        Tests = testResultAction.getResult().getResultInRun(currentBuild.rawBuild).getFailedTests()
        Tests.addAll(testResultAction.getResult().getResultInRun(currentBuild.rawBuild).getPassedTests())
        Tests.addAll(testResultAction.getResult().getResultInRun(currentBuild.rawBuild).getSkippedTests())
        if(jobName.toUpperCase().contains("/QETEST/")) {
            for (int i = 0; i < Tests.size(); i++) {
                //def readContent = readFile 'junitreport.txt'
                def testresult = Tests[i].getFullName() + "--" + Tests[i].getAge() + "--" + Tests[i].getDuration() + "--" + Tests[i].getStatus()
                print testresult
                /*if (isUnix()) {
                    sh """
                            echo "${testresult}">>junitreport.txt
                        """
                } else{
                    bat """
                            echo "${testresult}">>junitreport.txt
                        """
                }*/
                //writeFile file: 'junitreport.txt', text: readContent+"\r\n"+testresult
            }
        }
        print TestCountTotal  + "--" + TestCountFailed + "--" + TestCountSkipped

    }

    //print "splunkins..."
    //msg="BNum="+buildNum+",JName="+jobName+",AppName="+appname+",CompName="+compname+",BranchName="+gitbranch+",JobStatus="+currentBuild.result+",JType="+jobType
    //print "splunkin msg: " + msg
    //splunkins.send(msg)
    if (isUnix()) {
        sh """
            echo "scrm analytics..."

        ${PYTHON} ${JENKINS_SCRM_ANALYTICS} -jobtype "${jobType}" -jobname "${jobName}" -jobstarttime "${startTime}" \
            -jobendtime "${date}" -jobdate "${date}" -pipeline "${pipelinename}" -component "${compname}" \
            -application "${appname}" -artifact "${artifact}" -release "${jiraVersion}" \
            -jira_project_name "${jiraProjectKey}"  -status "${currentBuild.result}" -username "${buildcause}" \
            -buildurl "${buildURL}" -git_hash "${git_commit}" -git_branch "${gitbranch}"  \
            -test_count_total "${TestCountTotal}" -test_count_failed "${TestCountFailed}"  \
            -test_count_skipped "${TestCountSkipped}" -environment "${envName}" -test_type "${testType}" \
            -deploy_env "${deploy_env}" -erm "${erm}"
        """

    } else {
        bat """
        @echo off
        echo "scrm analytics..."

        %PYTHON% %JENKINS_SCRM_ANALYTICS% -jobtype "${jobType}" -jobname "${jobName}" -jobstarttime "${startTime}" \
            -jobendtime "${date}" -jobdate "${date}" -pipeline "${pipelinename}" -component "${compname}" \
            -application "${appname}" -artifact "${artifact}" -release "${jiraVersion}" \
            -jira_project_name "${jiraProjectKey}"  -status "${currentBuild.result}" -username "${buildcause}" \
            -buildurl "${buildURL}" -git_hash "${git_commit}" -git_branch "${gitbranch}"  \
            -test_count_total "${TestCountTotal}" -test_count_failed "${TestCountFailed}"  \
            -test_count_skipped "${TestCountSkipped}" -environment "${envName}" -test_type "${testType}" \
            -deploy_env "${deploy_env}" -erm "${erm}"
        """
    }
}
