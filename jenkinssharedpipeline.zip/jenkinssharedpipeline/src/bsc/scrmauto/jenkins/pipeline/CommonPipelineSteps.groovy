#!/usr/bin/env groovy
/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */
package bsc.scrmauto.jenkins.pipeline

/**
 * This method cleans current workspace
 *
 */
def CleanWorkspace() {
    //echo 'Cleaning workspace'
    deleteDir()
}

/**
 * This method will do mvn build using jenkins maven pipeline plugin
 *
 */

def mvnbuild(String mvnVersion, String pomPath, String mvnGoals, String jdkversion="") {

////    boolean mvndeploy = false
////
////    if (mvnGoals.toLowerCase().contains('deploy')) {
////        mvndeploy = true
//    }
    pom = readMavenPom file: pomPath+'/pom.xml'
    pomVersion = pom.version.replace("-SNAPSHOT","").trim()
    echo "{$env.mvndeploy}"
    dir(pomPath) {
        if (env.mvndeploy.toBoolean()) {
            currentBuild.displayName = '#' + pomVersion + ".${env.BUILD_ID}"
            withMaven(maven: mvnVersion,
                    //jdk: jdkversion,
                    mavenLocalRepo: "${env.WORKSPACE}/.m2",
                    mavenSettingsConfig: 'jenkins-maven-settings.xml',
                    options: [artifactsPublisher(disabled: false)]) {

                sh """
                    mvn $mvnGoals
                """

            }
        } else {
            if (isUnix()) {
                //echo "Running in unix.."
                withMaven(maven: mvnVersion,
                        //jdk: jdkversion,
                        mavenLocalRepo: "${env.WORKSPACE}/.m2",
                        mavenSettingsConfig: 'jenkins-maven-settings.xml',
                        options: [artifactsPublisher(disabled: true)]) {

                    sh """
                    mvn $mvnGoals
                """

                }
            } else {
                //echo "Running in windows.."
                withMaven(maven: mvnVersion,
                        //jdk: jdkversion,
                        mavenLocalRepo: "${env.WORKSPACE}\\.m2",
                        mavenSettingsConfig: 'jenkins-maven-settings.xml',
                        options: [artifactsPublisher(disabled: true)]) {

                    bat """
                            mvn $mvnGoals
                        """

                }

            }
        }
    }
}

/**
 * This method will do Prebuild script run, if script exisit in the branch
 *
 */

def prebuildscript(){
    def ParseCommonVars = new ParseCommonVars()
    findFile = "branchscope.properties"
    check = fileExists findFile
    if ( check == true ){
        ParseCommonVars.loadProperties("branchscope.properties")
        echo "loaded branchscope.properties"
    }

    if (isUnix()) {
        def exists = fileExists 'prebuild.sh'
        if (exists) {
            sh ('sh prebuild.sh')
        }
    } else{
        def exists = fileExists 'prebuild.bat'
        if (exists) {
            bat ('call prebuild.bat')
        }
    }
}

/**
 * This method will do Postbuild script run, if script exisit in the branch
 *
 */


def postbuildscript(){

    if (isUnix()) {
        def exists = fileExists 'postbuild.sh'
        if (exists) {
            echo "Running postbuild.sh .."
            sh ('sh postbuild.sh')
        }
    } else{
        def exists = fileExists 'postbuild.bat'
        if (exists) {
            echo "Running postbuild.bat .."
            bat (readFile("postbuild.bat"))
        }
    }
}