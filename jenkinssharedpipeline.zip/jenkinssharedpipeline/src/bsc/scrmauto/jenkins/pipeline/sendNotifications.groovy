#!/usr/bin/env groovy

/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */

package bsc.scrmauto.jenkins.pipeline

/**
 * This method sends notifications with build result to mail recipients
 */

def notifypost(String mailRecipients) {
    //echo "${mailRecipients}"
    //def GitUtils = new GitUtils()

    if (mailRecipients == "null") {
        mailRecipients = " "
    } else {
        echo "RequesterRecipient : " + mailRecipients
    }

    if (env.CHANGE_AUTHOR_EMAIL) {
        mailRecipients = mailRecipients +"${env.CHANGE_AUTHOR_EMAIL}"
    }


    /*def devemails = GitUtils.getChangeauthoremail()

    if (!devemails?.trim()) {
        devemails = ""
    }*/


    currentBuild.result = currentBuild.currentResult
    currentBuild.result = currentBuild.result ?: 'SUCCESS'
    //currentBuild.changeSets = currentBuild.rawBuild.changeSets

    //echo "DevelopersRecipient : " + devemails
    def jobName = currentBuild.fullDisplayName
    //def attachLog = (config.attachLog != null) ? config.attachLog : (currentBuild.result != "SUCCESS") // Attach buildlog when the build is not successfull



    emailext(
            recipientProviders: [
                    [$class: 'UpstreamComitterRecipientProvider'],
                    [$class: 'RequesterRecipientProvider'],
                    [$class: 'DevelopersRecipientProvider'],
                    [$class: 'FailingTestSuspectsRecipientProvider'],
                    [$class: 'FirstFailingBuildSuspectsRecipientProvider']
            ],
            body: '${JELLY_SCRIPT, template="email_for_newmobile"}',
            mimeType: 'text/html',
            subject: "[Jenkins] \"${currentBuild.result}: Job '${jobName} [${env.BUILD_NUMBER}]'\"",
            replyTo: "${mailRecipients}",
            to: "${mailRecipients}"
    )
}