#!/usr/bin/env groovy
/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */
package bsc.scrmauto.jenkins.pipeline

import com.cloudbees.groovy.cps.NonCPS



/**
 * This method is used to find if the current machine is a WINDOWS or UNIX machine
 * If WINDOWS machine it will git using the method: procCommand
 * Else it will run git in shell for UNIX
 * @return exit value 0 or 1
 */
boolean insideWorkTree() {
    def Utils = new Utils()
    if (Utils.whichOS() == "WINDOWS") {
        def proc = bat('git rev-parse --is-inside-work-tree')
        return (0 == "${proc.exitValue()}")
    } else if (Utils.whichOS() == "UNIX") {
        return sh(returnStatus: true, script: 'git rev-parse --is-inside-work-tree 1>/dev/null 2>&1') == 0
    }
}

/**
 * This method returns the git commit ID
 * @return git commit ID if committed else returns NULL
 */
String getGitCommitIdOrNull() {
    if (insideWorkTree()) {
        return getGitCommitId()
    } else {
        return null
    }
}

/**
 * @return git commit ID irrespective of where git is run on WINDOWS or UNIX
 */
String getGitCommitId() {
    def Utils = new Utils()
    if (Utils.whichOS() == "WINDOWS") {
        def proc = bat('git rev-parse HEAD')
        return "${proc.in.text}"
    } else if (Utils.whichOS() == "UNIX") {
        return sh(returnStdout: true, script: 'git rev-parse HEAD').trim()
    }
}


String getGitFirstCommitID() {
    def Utils = new Utils()
    if (Utils.whichOS() == "WINDOWS") {
        def proc = bat('git rev-parse HEAD')
        return "${proc.in.text}"
    } else if (Utils.whichOS() == "UNIX") {
        return sh(returnStdout: true, script: 'git reflog show --no-abbrev | tail -n 1 | awk \'{print $1}\'').trim()
    }

}


@NonCPS
/**
 * This method creates a lit of changes for the current build
 */
def emailCreateChangeList() {
    def changeLogSets = currentBuild.rawBuild.changeSets
    for (int i = 0; i < changeLogSets.size(); i++) {
        def entries = changeLogSets[i].items
        for (int j = 0; j < entries.length; j++) {
            def entry = entries[j]
            echo "${entry.commitId} by ${entry.author} on ${new Date(entry.timestamp)}: ${entry.msg}"
            def files = new ArrayList(entry.affectedFiles)
            for (int k = 0; k < files.size(); k++) {
                def file = files[k]
                echo " ** ${file.editType.name}| ${file.path}"
            }
        }
    }
}

/**
 *
 * @return the last successful git commit
 */

def getLastSuccessfulCommit() {
    def lastSuccessfulHash = this.env.GIT_PREVIOUS_SUCCESSFUL_COMMIT
    //echo lastSuccessfulHash
    if (lastSuccessfulHash == null) {
        return getGitFirstCommitID()
    } else {
        return lastSuccessfulHash
    }
}

/**
 *
 * @return git commit Hash ID
 */
def getGitCommitHash() {
    def GitCommitHash = this.env.GIT_COMMIT
    //echo GitCommitHash
    if (GitCommitHash == null) {
        return getGitCommitIdOrNull()
    } else {
        return GitCommitHash
    }
}

/**
 *
 * @return git commit Hash ID
 */


def getRevisionID() {
    def Utils = new Utils()
    if (Utils.whichOS() == "WINDOWS") {
        def stdout = bat(returnStdout: true, script: 'git rev-list HEAD | find /v /c "" ').trim()
        result = stdout.readLines().drop(1).join(" ")
        return result
    } else if (Utils.whichOS() == "UNIX") {
        return sh(returnStdout: true, script: 'git rev-list HEAD | wc -l').trim()
    }
}

/**
 *
 * @return List of changes for the current build
 */
//TODO-Shilpa Covert Changelist txt file to html
//TODO-Shilpa Explore JGIT to perform Git operations instead of Git CLI

def getChangelist(startrevision, endrevision) {
    if ((startrevision != null) && (endrevision != null)) {
        if (startrevision == endrevision) {
            writeFile file: "${WORKSPACE}//gitChangeList.txt", text: 'No Changes found from last build!'
        } else {
            def Utils = new Utils()
            echo "Creating changelist"
            def unixmylogcmd = "git log --name-status HEAD --pretty=format:'%C(yellow)%h%Creset %C(green)%an%Creset,%C(red)%cr%Creset: %C(cyan)%s%Creset' -3"
            def mychagelistcmd = "git log --name-status ${startrevision}...${endrevision}"
            def unixmychagelistcmd = "git log --name-status --pretty=format:\"<tr><br><br/> <td><font color='blue'>%h</font></td>&nbsp;&nbsp;<td><font color='green'>%an</font></td>&nbsp;&nbsp;<td><font color='red'>%ad</font><td>&nbsp;&nbsp;: <td><font color ='#660066'>%s</font></td>&nbsp;&nbsp;<br/><tr>\" ${startrevision}...${endrevision}"

            def mylogcmd = "git log --name-status HEAD -3"
            //def startrevision = getGitCommitHash()
            //def endrevision = getLastSuccessfulCommit()
            //def format = "<tr><br><br/> <td><font color='blue'>%h</font></td>&nbsp;&nbsp;<td><font color='green'>%an</font></td>&nbsp;&nbsp;<td><font color='red'>%ad</font><td>&nbsp;&nbsp;: <td><font color ='#660066'>%s</font></td>&nbsp;&nbsp;<br/> <tr>"
            ansiColor('xterm') {
                if (Utils.whichOS() == "WINDOWS") {
                    //bat "$mylogcmd"
                    stdout = bat(returnStdout: true, script: "$mychagelistcmd>%WORKSPACE%\\gitChangeList.txt | exit /b 0")
                    result = stdout.readLines().drop(1).join(" ")
                    return result
                } else {
                    echo "Last 3 commits on the branch"
                    sh "$unixmylogcmd"
                    return sh("$mychagelistcmd>${WORKSPACE}/gitChangeList.txt || true")
                }
            }
        }

    } else {
        echo "Skipping changelist creation as it is first build!"
        writeFile file: "${WORKSPACE}//gitChangeList.txt", text: 'Skipping changelist creation as it is first build!'
    }
    //archiveArtifacts "${WORKSPACE}\\gitChangeList.txt"
}

@NonCPS
def getChangelist() {
    MAX_MSG_LEN = 100
    def entries = ""
    def changes = "Build Changes: \n"
    echo "Creating changlist"
    def changeLogSets = currentBuild.rawBuild.changeSets
    for (int i = 0; i < changeLogSets.size(); i++) {
        entries = changeLogSets[i].items
        for (int j = 0; j < entries.length; j++) {
            def entry = entries[j]
            changes += "\n Commit Hash:         ${entry.commitId}"
            changes += "\n Author:              ${entry.author}"
            changes += "\n Date:                ${new Date(entry.timestamp)}"
            changes += "\n Commit Message:      ${entry.msg}\n"
            //echo "${entry.commitId} by ${entry.author} on ${new Date(entry.timestamp)}: ${entry.msg}"
            def files = new ArrayList(entry.affectedFiles)
            for (int k = 0; k < files.size(); k++) {
                def file = files[k]
                changes += "\n\t${file.editType.name}:          ${file.path}"
                //echo "  ${file.editType.name} ${file.path}"
            }
            changes += "\n------------------------------------------------------------------------------\n"
        }
    }

    if (!entries) {
        changes = "- No new changes \n"
        writeFile file: "gitChangeList.txt", text: changes
        echo entries
    } else {
        writeFile file: "gitChangeList.txt", text: changes
    }

}


def getChangeauthoremail() {
    def committerEmail = ""
    def Utils = new Utils()
    dir("${env.BRANCH_NAME}") {
        def startrevision = "${env.GIT_COMMIT}"
        def endrevision = "${env.GIT_PREVIOUS_SUCCESSFUL_COMMIT}"
        if ((startrevision != null) || (endrevision != null)) {
            if (Utils.whichOS() == "WINDOWS") {
                def commiterDetails = bat(
                        script: 'git --no-pager show -s --format=%%ae',
                        returnStdout: true
                )
                committerEmail = extractCommiterEmail(commiterDetails)

            } else if (Utils.whichOS() == "UNIX") {
                committerEmail = sh(
                        script: 'git --no-pager show -s --format=\'%ae\'',
                        returnStdout: true
                ).trim()
            }

        } else {
            echo "Skipping changelist creation as it is first build!"
        }
    }
    return committerEmail
}


def extractCommiterEmail(details) {

    def arr = details.tokenize('\n')
    def email = arr[2].trim()
    return email
}
//'git --no-pager show -s --format=\'%ae\'',
//git log 88d39c5edc09776882d00ca0b920e6740b298f11...d92e09f4a5a4c1565a738ef9343cde1e4d9dffee --format="%aE" | sort -u | sed ':a;{N;s/\n/,/};ba'
