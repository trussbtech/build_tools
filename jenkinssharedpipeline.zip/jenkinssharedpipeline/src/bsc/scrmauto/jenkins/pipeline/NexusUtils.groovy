#!/usr/bin/env groovy
package bsc.scrmauto.jenkins.pipeline

/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */


def Uploadartifact(String appname, String compname, String jiraVersion, String ZIP_TAG) {
    def Utils = new Utils()
    //def JENKINS_NEXUS_UPLOADMVN_SCRIPT = "${env.JENKINS_NEXUS_UPLOADMVN_SCRIPT}"
    //def ParseCommonVars = new ParseCommonVars()
    echo appname
    echo compname
    //jiraVersion = ParseCommonVars.getJiraVersion()
    currentBuild.description = "${ZIP_TAG}"
    currentBuild.displayName = '#' + "${jiraVersion}" + '.' + "${env.BUILD_ID}"

    withEnv(["PRJ_KEY=${appname}", "JIRA_APP=${compname}"]) {

        if (Utils.whichOS() == "WINDOWS") {
            bat """
                    @echo off
                    %PYTHON% %JENKINS_NEXUS_UPLOAD% -a %WORKSPACE%\\${ZIP_TAG}
                  """
        } else {
            sh """
                    #!/bin/sh
                    ${PYTHON} ${JENKINS_NEXUS_UPLOAD} -a ${WORKSPACE}/${ZIP_TAG}
                """
        }
    }

}

