package bsc.scrmauto.jenkins.pipeline

import bsc.scrmauto.jenkins.pipeline.bitbucket.restclient
import java.io.File

/**
 *
 * @param gituri - git url of application
 * @return Application name
 */


def getAppname(gituri) {

    def appname
    if (gituri.startsWith("ssh")) {
        appname = gituri.split('/')[3]
    } else {
        appname = gituri.split('/')[4]
    }
    //echo "appname = "+appname
    return appname.toString().toLowerCase()
}

/**
 *
 * @param gituri - git url of application
 * @return Component Name
 */
def getCompname(gituri) {
    def restclient = new restclient()
    def compname
    if (gituri.startsWith("ssh")) {
        compname = gituri.split('/')[4].replace(".git", "").trim()
    } else {
        compname = gituri.split('/')[5].replace(".git", "").trim()
    }

    def uriloc = getAppname(gituri) + "/repos/" + compname
    //echo uriloc
    def parsedCompname = restclient.getRC("${uriloc}")
    //echo parsedCompname
    if(parsedCompname) {
        compname = parsedCompname
    }

    //echo "compname = "+compname
    return compname.toString()
}

def getJiraVersion() {
    properties = readProperties file: 'component.properties'
    String releaseVersion = properties.release
    if (releaseVersion.contains("-")) {
        String[] arrString = releaseVersion.split("-")
        releaseVersion = arrString[1]
    }

    return releaseVersion
}

def getactualJiraVersion() {
    properties = readProperties file: 'component.properties'
    String releaseVersion = properties.release
    return releaseVersion
}

def getJiraKey() {
    properties = readProperties file: 'component.properties'
    String jiraKey = properties.jirakey

    return jiraKey
}


def loadProperties(String path) {
    def props = readProperties file: path
    keys = props.keySet()
    for (key in keys) {
        value = props["${key}"]
        env."${key}" = "${value}"
    }
}

def getProperty(String propertyKey, String path){
    Properties props = new Properties()
    File propsFile = new File(${path})
    props.load(propsFile.newDataInputStream())
//    propsFile = readProperties file: path
    propertyValue = props.getProperty(${propertyKey})
    echo "propertyValue: ${propertyValue}"

    return propertyValue
}

def setProperty(String path, String propertyKey, String propertyValue) {
    echo "Inside set property"
    Properties props = new Properties()
    File propertyFile = new File("./envconfig/${path}")
    props.load(propertyFile.newDataInputStream())
    echo "loaded file: ${path}"
    props.setProperty(${propertyKey}, ${propertyValue})
    echo "setting property: ${propertyKey} with ${propertyValue}"
    props.store(propsFile.newWriter(), null)

//    def props1 = readProperties file: path
//    value1 = props1["${propertyKey}"]
//    newValue = ${propertyValue}
//    props1["${propertyKey}"] = newValue
//    Properties propsTryout = new Properties()
//    propsTryout.setProperty(${propertyKey}, ${propertyValue})
//    propsTryout.st


    return

}

