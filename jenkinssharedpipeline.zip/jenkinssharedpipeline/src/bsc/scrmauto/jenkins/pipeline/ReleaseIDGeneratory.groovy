package bsc.scrmauto.jenkins.pipeline



def script

/**
 *
 * @param script - that contains Fix Version and Build ID
 */
def ReleaseIDGenerator(script) {
    this.script = script
}

/**
 *
 * @return Fix Version, Build ID and Git Commit ID
 */
def generate() {
    def version = script.readFile('VERSION').trim()
    def buildID = script.env.BUILD_ID
    def shortSha = script.env.GIT_COMMIT.take(7)

    return "${version}+b${buildID}.${shortSha}"
}
