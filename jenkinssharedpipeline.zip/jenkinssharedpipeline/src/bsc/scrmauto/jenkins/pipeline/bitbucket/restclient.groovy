package bsc.scrmauto.jenkins.pipeline.bitbucket


import bsc.scrmauto.jenkins.pipeline.Constants
import groovy.json.JsonSlurper
import org.json.JSONObject

def getRC(urlstr) {
    def Constants = new Constants()
    //def UtilsGlobals = new UtilsGlobals()
    //def urlstr = 'fad/repos/fadintegrationservice'
    //echo urlstr
    def uri
    uri = "${env.restapibburi}"
    //echo uri

    if (!uri?.trim()) {
        uri = Constants.restapibburi
    }

    urlstr = uri + urlstr

    //echo urlstr
    withCredentials([usernamePassword(credentialsId: 'jenkins-bitbucket-prod', passwordVariable: 'bbpassword', usernameVariable: 'bbusername')]) {
        def getRC
        def uname = "${bbusername}"
        def upasswd = "${bbpassword}"

        def RESPONSE_OK = 200
        def get = new URL(urlstr).openConnection()

        def authString = "$uname:$upasswd".getBytes().encodeBase64().toString()
        get.setRequestProperty("Authorization", "Basic ${authString}")

        getRC = get.getResponseCode()

        if (getRC.equals(RESPONSE_OK)) {
            def jsonCTX = new JsonSlurper().parseText(get.getInputStream().getText())
            if (jsonCTX)
                jsonCTX.name
            else
                echo "parse jsonCTX - name not found"
        } else {
            echo "url open connection failed"
        }
    }
}

def postRC(urlstr , body ){

    withCredentials([usernamePassword(credentialsId: 'jenkins-bitbucket-prod', passwordVariable: 'bbpassword', usernameVariable: 'bbusername')]) {
        def getRC
        def uname = "${bbusername}"
        def upasswd = "${bbpassword}"

        def RESPONSE_OK = 200
        def get = new URL(urlstr).openConnection()

        def authString = "$uname:$upasswd".getBytes().encodeBase64().toString()

        get.setRequestMethod("POST");
        get.setRequestProperty("Accept", "text/plain");
        get.setRequestProperty("Content-Type", "text/plain");
        get.setRequestProperty("Authorization", "Basic ${authString}")

        get.setDoOutput(true);

        OutputStream outStream = get.getOutputStream();
        OutputStreamWriter outStreamWriter = new OutputStreamWriter(outStream, "UTF-8");
        outStreamWriter.write(body);
        outStreamWriter.flush();
        outStreamWriter.close();
        outStream.close();

        getRC = get.getResponseCode()

        if (getRC.equals(RESPONSE_OK)) {
            InputStream outResp = get.getInputStream();

            String result;
            BufferedInputStream bis = new BufferedInputStream(get.getInputStream());
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            int op = bis.read();
            while(op != -1) {
                buf.write((byte) op);

                op = bis.read();
            }

            JSONObject response = new JSONObject(buf.toString())
            //println(response)

            ProdRelVersion = response["range"]["total"]
            echo "ProdRelVersion: " + ProdRelVersion
            if ( ProdRelVersion != 0 ) {
                echo "This is Prod Fix Version"
                error("ERROR: This Release version has been already used in the prod. Please update the correct version in component.properties file and do the rebuild!")
            }
            else {
                echo "This is not a Prod Fix Version"
            }

        } else {
            echo "url open connection failed"
        }
    }


}


