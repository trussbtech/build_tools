#!/usr/bin/env groovy
/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */
package bsc.scrmauto.jenkins.pipeline

import com.cloudbees.groovy.cps.NonCPS

@NonCPS
def commentChangeIssueszip(String jiraProjectKey, String zipTag) {
    def issue_pattern = jiraProjectKey.toUpperCase() + "-\\d+"
    def jiraList = []
    jiraList = jiraList as Set
    // Find all relevant commit ids
    currentBuild.changeSets.each { changeSet ->
        changeSet.each { commit ->

            String commitId = commit.getCommitId()
            String msg = commit.getMsg().toUpperCase()
            msg.findAll(issue_pattern).each { id ->
                    // Actually post a comment
                //echo issue_pattern
                jiraList << [id     : id,
                             comment: "[Jenkins] SUCCESS: Integrated in !" + env.JENKINS_URL + "/images/16x16/blue.png! [" + env.JOB_NAME + "#" + env.BUILD_ID + "|" + env.BUILD_URL + "] \n" + msg + "\nARTIFACT: " + zipTag]
            }
        }
    }
    return jiraList
}


def getERM(String jiraVersion) {
    String ermjql = "project = ERM AND \"Release Contents\" = " + jiraVersion
    def issues = jiraJqlSearch jql: ermjql, site: 'jira'
    String erm = ""
    int ermcount = 0
    ermcount = issues.data.issues.size()
    if (ermcount > 0) {
        erm = issues.data.issues[0].key.toString()
        echo erm
    } else {
        error("ERROR: NO ERM Ticket found!")
    }
    return erm
}
