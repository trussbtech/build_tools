#!/usr/bin/env groovy

/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */

import bsc.scrmauto.jenkins.pipeline.*

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def ParseCommonVars = new ParseCommonVars()
    def Utils = new Utils()
    def GitUtils = new GitUtils()
    def ArtifactoryUtils = new ArtifactoryUtils()
    def sendNotification = new sendNotifications()

    def arr = "${config.buildenv}"
    def pollscm = "${config.Pollscm}"
    def nodejsVersion = "${config.nodejsVersion}"
	def jdkversion = "${config.jdkversion}"
    def mailRecipients = "${config.mailRecipients}"

    def rhelNode = 'rhel-node'

    def gitbranch
    def gituri
    def git_commit
    def git_previous_successful_commit
    def gitrevisionid
    def appname
    def compname
    def jiraVersion
    def properties
    def ZIP_TAG


     //Running build for parallel
    echo "Running commands: ${arr}"
    int top = arr.size()
    echo "top is ${top}"
    //Load all commands to map
    def stepsForParallel = [:]

    for (int i = 0; i < arr.size(); i++) {
        def it = arr[i]
        def stepName = "${it}"
        stepsForParallel[stepName] = { ->
            echo "Running ${it} build..."
            sh """
				cd ${WORKSPACE}/${BRANCH_NAME}
				npm run build-${it}
                mkdir ${WORKSPACE}/dist/du_full/${it}
				cp -rf ${WORKSPACE}/${BRANCH_NAME}/${it}/dist/ ${WORKSPACE}/dist/du_full/${it}
			   """

        }
    }

    pipeline {

        triggers {
            pollSCM("${pollscm}")
        }

        agent {
            node {
                label "${rhelNode}"
            }
        }

        options {
            skipDefaultCheckout(true)
            buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '10'))
        }


        tools {
            jdk "${jdkversion}"
        }

        stages {

            stage("Git clone") {
                steps {
                    deleteDir()
                    script {
                        //Utils.printEnv()
                        dir("${env.BRANCH_NAME}") {
                            def scmProp = checkout scm

                            git_commit = scmProp.GIT_COMMIT
                            git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
                            gitbranch = scmProp.GIT_BRANCH
                            gituri = scmProp.GIT_URL

                            // For PR gituri will be NULL
                            if (gituri) {
                                appname = ParseCommonVars.getAppname(gituri)
                                compname = ParseCommonVars.getCompname(gituri)

                                properties = readProperties file: 'component.properties'
                                jiraVersion = properties.release
                                ZIP_TAG = appname + '-' + compname + '-' + "${jiraVersion}" + '.' + "${env.BUILD_ID}" + '.zip'
                                gitrevisionid = GitUtils.getRevisionID()
                                echo gitrevisionid
                                GitUtils.getChangelist(git_commit, git_previous_successful_commit)
                            }
                        }
                    }
                }
            }

            stage("Initialize nodeJS") {
                steps {
                    script {
                        dir("${env.BRANCH_NAME}") {
                            node = tool name: nodejsVersion, type: 'jenkins.plugins.nodejs.tools.NodeJSInstallation'
                            env.PATH = "${node}/bin:${env.PATH}"
                            sh '''
                                echo $PATH
                                npm --version
                                node --version
                                npm install
                                ng set --global warnings.versionMismatch=false
                                ng version
                            '''
                        }
                        sh '''
                            echo copying ${JENKINS_ARTIFACT_TEMPLATE_ZIP}
                            cp ${JENKINS_ARTIFACT_TEMPLATE_ZIP} .
                            '''

                        //unzip dir: 'dist', glob: '', zipFile: 'JenkinsArtifactTemplate.zip'
                        Utils.unzip("dist", "JenkinsArtifactTemplate.zip",)
                        //Utils.printEnv()
                    }
                }

            }

            stage("Build") {
                steps {
                    script {
                        ansiColor('xterm') {
                            parallel stepsForParallel
                        }
                        //echo "Skip Build test"
                    }
                }
            }


            stage("Test") {
                steps {
                    sh '''
						 cd ${WORKSPACE}/${BRANCH_NAME}
						 echo "npm test"
					   '''
                }
            }


            stage("Artifactory Upload") {
                //Condition to ignore this stage for PR
                when {
                    expression {
                        !gitbranch.contains("PR-")
                    }
                }

                steps {
                    script {
                        Utils.copyflat("${env.BRANCH_NAME}", "dist/du_full", "**/*.${artifacttype}")
                        echo "${env.ZIP_TAG}"
                        Utils.zip("dist", "${env.ZIP_TAG}", ".")
                        ArtifactoryUtils.Uploadartifact(env.gituri, env.gitbranch, env.jiraVersion, env.git_commit, env.ZIP_TAG, env.erm)
                        archiveArtifacts '*-*-*.zip,gitChangeList.txt'
                    }

                }
            }
        }

        post {
            always {
                script {
                    sendNotification.notifypost("$mailRecipients")
                }

            }
            success {
                script {
                    echo "JIRAKEY:${env.jiraProjectKey}"
                    echo "ZIPTAG:${env.ZIP_TAG}"
                    jiraSteps.commentChangeIssueszip(env.jiraProjectKey, env.ZIP_TAG).each { jiraChange ->
                        jiraAddComment(idOrKey: jiraChange.id,
                                comment: jiraChange.comment,
                                failOnError: false,
                                site: "jira"
                      
                        )
                    }
                    
                    echo "JOB COMPLETED SUCCESSFULLY"
                    }
                }
            }
        }
    }
