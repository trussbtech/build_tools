/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */

import bsc.scrmauto.jenkins.pipeline.*

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    def ParseCommonVars = new ParseCommonVars()
    def GitUtils = new GitUtils()
    def Utils = new Utils()
    def Constants = new Constants()
    def initNodeJs = new initNodeJs()
    def ArtifactoryUtils = new ArtifactoryUtils()

    def gituri = "${config.gituri}"
    def gitbranch = "${env.BRANCH_NAME}"
    def git_cred = Constants.git_credentials
    def antVersion = 'ant-1.7.1'

    def rhelNode = 'rhel-node'
    def appname = ParseCommonVars.getAppname(gituri)
    def compname = ParseCommonVars.getCompname(gituri)
    def jiraVersion = "${config.jiraVersion}"
    ZIP_TAG = appname + '-' + compname + '-' + "${jiraVersion}" + '.' + "${env.BUILD_ID}" + '.zip'
    echo "${ZIP_TAG}"

    def arr = config.buildenv
    echo "Running commands: ${arr}"
    int top = arr.size()
    echo "top is ${top}"
    def stepsForParallel = [:]

    for (int i = 0; i < arr.size(); i++) {
        def it = arr[i]
        def stepName = "${it}"
        stepsForParallel[stepName] = { ->
            echo "Running ${it} build..."
            sh """
				cd ${WORKSPACE}
				npm run build-${it}
				cp -rf ${WORKSPACE}/${it} ${WORKSPACE}/dist/du_full/
			   """

        }
    }

    node("${rhelNode}") {
        // Clean workspace before doing anything
        deleteDir()
        try {
            stage('Git Clone') {
                sh "echo 'checkout scm $gitbranch'"
                git(url: "${gituri}", branch: "${gitbranch}", changelog: true, poll: true, credentialsId: "${git_cred}")

            }
            stage('Initialize nodeJS ') {

                def node = tool name: "${config.nodejsVersion}", type: 'jenkins.plugins.nodejs.tools.NodeJSInstallation'
                env.PATH = "${node}/bin:${env.PATH}"
                sh '''
    					cd ${WORKSPACE}
						echo copying ${BUILD_XML}
						cp ${BUILD_XML} .

						echo copying ${JENKINS_ARTIFACT_TEMPLATE_ZIP}
						cp ${JENKINS_ARTIFACT_TEMPLATE_ZIP} .
						
						echo $PATH
						npm --version
						node --version
						npm config set registry http://uapp958n:8081/artifactory/api/npm/registry.npmjs.org/
						npm install
						ng set --global warnings.versionMismatch=false
						ng version
					'''
                withEnv( ["ANT_HOME=${tool antVersion}"] ) {
                    sh '$ANT_HOME/bin/ant -file build.xml -Ddest=dist -Dsrc=JenkinsArtifactTemplate.zip unzip'
                }
                Utils.printEnv()


            }


            stage('Build') {
               // parallel stepsForParallel
            }

            stage('Test') {
                echo 'Testing...'
                sh '''
						 cd ${WORKSPACE}
						 echo "npm test"
					   '''
            }


            stage('Artifactory Upload') {
                //sh "$ANT_HOME/bin/ant -file build.xml -Ddest=. -Dprefix= -DzipFileName=${ZIP_TAG} -Dsrc=dist -Dexcludes=**/application.json zip"
                withEnv( ["ANT_HOME=${tool antVersion}"] ) {
                    sh "$ANT_HOME/bin/ant -file build.xml -Ddest=. -Dprefix= -DzipFileName=${ZIP_TAG} -Dsrc=dist -Dexcludes=**/application.json zip"
                }

                archiveArtifacts '**/*-*.zip'

                //ArtifactoryUtils.Uploadartifact(gituri, gitbranch, jiraVersion)

            }
            currentBuild.result = 'SUCCESS'
        } catch (err) {
            currentBuild.result = 'FAILED'
            //sendNotifications currentBuild.result
            throw err
        }
    }
}