#!/usr/bin/env groovy

/**
 * @author cluc01 , mcheck01
 * @Team IT-SCRM-Automation
 */
import bsc.scrmauto.jenkins.pipeline.*

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    def parseCommonVars = new ParseCommonVars()
    def utils = new Utils()
    def gitUtils = new GitUtils()
    def artifactoryUtils = new ArtifactoryUtils()
    def sendNotification = new sendNotifications()
    def gitBranch
    def gitURI
    def git_commit
    def git_previous_successful_commit
    def releaseVersion
    def properties
    def ZIP_TAG
    def pollscm = config.pollSCM
    def msbuildVersion = config.msbuildVersion
    def appName = config.appName
    def compName = config.compName
    def dotnetSolFilename = config.dotnetSolFilename
    def jenkinsNode = "windows-slave"
    def msbuildPath = ""
    def artifactType = config.artifactType
    def nugetBinPath = "${NUGET_BIN_PATH}" + "\\NuGet"
    def bscNugetRepoPath = "${BSC_NUGET_REPO_PATH}"
    def assemblyFilename = config.assemblyFilename
    def assemblySearchVersion = config.assemblySearchVersion

    //Validate the MSBuild version #
    if (msbuildVersion.equals("2017")) {
        msbuildPath = "${MSBUILD_2017_PATH}" + "\\MSBuild.exe"
    } else {
        echo "Invalid MSBuild version #.  It should be MSBuild version 2017."
        currentBuild.result = 'FAILURE'
        return
    }

    //Validate the artifact type.  //Todo:  Add more type down the road.
    if (!artifactType.equals("dll")) {
        echo "Invalid artifact type.  Acceptable values are dll, msi."
        currentBuild.result = 'FAILURE'
        return
    }

    pipeline {
        triggers {
            pollSCM("${pollscm}")
        }

        agent {
            node {
                label "${jenkinsNode}"
            }
        }

        options {
            skipDefaultCheckout(true)
            buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '10'))
        }

        /*
        tools {
            jdk "java_1.8_74"
        }
        */

        stages {
            stage("Git clone") {
                steps {
                    deleteDir()
                    script {
                        def scmProp = checkout scm

                        git_commit = scmProp.GIT_COMMIT
                        git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
                        gitBranch = scmProp.GIT_BRANCH
                        gitURI = scmProp.GIT_URL

                        //Todo: Once the casing is fixed, enable these functions
                        //appName = parseCommonVars.getAppname(gitURI)
                        //compName = parseCommonVars.getCompname(gitURI)

                        properties = readProperties file: "./component.properties"
                        releaseVersion = properties.release

                        /*
                        if (artifactType.equals("dll")){
                            //ZIP_TAG = appname + '-' + compname + '-' + "${jiraVersion}" + '.' + "${env.BUILD_ID}" + '.zip'
                        }
                        */

                        //GitUtils.getChangelist(git_commit, git_previous_successful_commit)
                    }
                }
            }

            /*
            stage("Initialize nodeJS") {
                steps {
                    script {
                        node = tool name: nodejsVersion, type: 'jenkins.plugins.nodejs.tools.NodeJSInstallation'
                        env.PATH = "${node}/bin:${env.PATH}"
                        sh '''
                            cd ${WORKSPACE}
                            echo copying ${BUILD_XML}
                            cp ${BUILD_XML} .
    
                            echo copying ${JENKINS_ARTIFACT_TEMPLATE_ZIP}
                            cp ${JENKINS_ARTIFACT_TEMPLATE_ZIP} .
                            
                            echo $PATH
                            npm --version
                            node --version
                            npm config set registry http://uapp958n:8081/artifactory/api/npm/registry.npmjs.org/
                            npm install
                            ng set --global warnings.versionMismatch=false
                            ng version
                        '''
                        unzip dir: 'dist', glob: '', zipFile: 'JenkinsArtifactTemplate.zip'
                        Utils.printEnv()
                    }
                }

            }
            */

            stage("Build") {
                steps {
                    script {
                        //parallel stepsForParallel

                        //Set assembly version
                        utils.replaceFileContent(assemblyFilename, assemblySearchVersion, "${releaseVersion}" + "." + "${env.BUILD_ID}")

                        //Compile
                        //bat "${msbuildPath}" + " " + "${dotnetSolFilename}" + " /t:Rebuild /p:OutDir=./bin/ /p:Configuration=Release;VersionAssembly=" + "${releaseVersion}" + '.' + "${env.BUILD_ID}"
                        bat "${msbuildPath}" + " " + "${dotnetSolFilename}" + " /t:Rebuild /p:OutDir=./bin/ /p:Configuration=Release"

                        //Generate NuGet spec file
                        def nuspecFilename = compName + ".nuspec"
                        bat "${nugetBinPath}" + " spec " + compName + " -Force"

                        //Modify the Nuget spec file content: adding author info, verion #, description, etc.
                        utils.replaceFileContent(nuspecFilename, "\$id\$", compName)

                        utils.replaceFileContent(nuspecFilename, "1.0.0", "${releaseVersion}" + "." + "${env.BUILD_ID}")
                        utils.replaceFileContent(nuspecFilename, "\$version\$", "${releaseVersion}" + "." + "${env.BUILD_ID}")

                        utils.replaceFileContent(nuspecFilename, "svnJenkins", "Blue Shield of California")
                        utils.replaceFileContent(nuspecFilename, "\$author\$", "Blue Shield of California")

                        utils.replaceFileContent(nuspecFilename, "Package description", appName + "/" + compName)
                        utils.replaceFileContent(nuspecFilename, "\$description\$", appName + "/" + compName)

                        //utils.replaceFileContent(nuspecFilename, "<projectUrl>http://PROJECT_URL_HERE_OR_DELETE_THIS_LINE</projectUrl>", "")
                        //utils.replaceFileContent(nuspecFilename, "<iconUrl>http://ICON_URL_HERE_OR_DELETE_THIS_LINE</iconUrl>", "")
                        //utils.replaceFileContent(nuspecFilename, "<licenseUrl>http://LICENSE_URL_HERE_OR_DELETE_THIS_LINE</licenseUrl>", "")
                        //utils.replaceFileContent(nuspecFilename, "Summary of changes made in this release of the package.", appName + "/" + compName)
                        //utils.replaceFileContent(nuspecFilename, "Tag1 Tag2", appName + "/" + compName)

                        //Generate the NuGet package file
                        //bat "${nugetBinPath}" + " pack " + compName + ".nuspec"
                        bat "${nugetBinPath}" + " pack"
                    }
                }
            }

            /*
            stage("Test") {
                steps {
                    sh '''
						 cd ${WORKSPACE}
						 echo "npm test"
					   '''
                }
            }
            */

            stage("Artifactory Upload") {
                steps {
                    script {
                        //echo "${ZIP_TAG}"
                        //zip dir: 'dist', glob: '', zipFile: "${ZIP_TAG}", archive: true
                        //Utils.zip("dist", "${ZIP_TAG}", "application.json")
                        //ArtifactoryUtils.Uploadartifact(gituri, gitbranch, jiraVersion, git_commit)

                        def nugetPackageName = compName + "." + releaseVersion + "." + "${env.BUILD_ID}" + ".nupkg"
                        artifactoryUtils.uploadNugetPackage(nugetPackageName, appName, compName, releaseVersion)
                    }
                }
            }
        }

        post {
            always {
                script {
                    echo "sending email"
                    sendNotification.notifypost()
                }
            }
        }
    }

    /*todo:
    1. ++ Get code
    2. ++ Read the property
    3. ++ Get build #
    0. ++ Injet the release # into the AssemblyInfo.*
    2. ++compile
    3. Generate package
        a. ++ nuget package
        b. ++ regular zip package
        c. ++ Push to artifactory
    5. ++ Notify email / hipchat
    6. ** Work on other components
    7. Generate that json or JIRA bundle (round 2)
    */
}