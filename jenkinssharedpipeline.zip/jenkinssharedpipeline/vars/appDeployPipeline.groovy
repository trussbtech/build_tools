/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */


import bsc.scrmauto.jenkins.pipeline.*

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def ParseCommonVars = new ParseCommonVars()
    def Utils = new Utils()
    def GitUtils = new GitUtils()
    def ArtifactoryUtils = new ArtifactoryUtils()
    def sendNotification = new sendNotifications()
    def pipelinename = this.class.getName()

    def arr = config.buildenv
    def deploy_cron = "${config.deploy_cron}"
    def checkDeployedfile = "${config.checkDeployedfile}"
    def mailRecipients = "${config.mailRecipients}"


    def rhelNode = 'windows-node'


    pipeline {

        triggers {
            cron("${deploy_cron}")
        }

        agent {
            node {
                label "${rhelNode}"
            }
        }


        options {
            skipDefaultCheckout(true)
            buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '10'))
        }


        stages {
            stage("Git clone") {
                steps {
                    deleteDir()
                    script {
                        //Utils.printEnv()
                        dir("${env.BRANCH_NAME}") {
                            def scmProp = checkout scm

                            git_commit = scmProp.GIT_COMMIT
                            git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
                            gitbranch = scmProp.GIT_BRANCH
                            gituri = scmProp.GIT_URL

                            // For PR gituri will be NULL
                            if (gituri) {
                                appname = ParseCommonVars.getAppname(gituri)
                                compname = ParseCommonVars.getCompname(gituri)
                                //TODO Pavan Validate compoenent properties
                            }
                        }
                        //Utils.printEnv()
                    }
                }
            }

            stage("Validate deployment request") {
                steps {
                    script {
                        bat '''
                               cd %WORKSPACE%
                               REM hostname
                               python "%EXTERNAL_TOOLS_TRUNK%\\JenkinsAppDeploytrigger\\appdeploytrigger.py"
                       '''

                        if (checkDeployedfile == "null") {
                            echo "skipping check files"
                        } else {
                            if(findFiles([glob: "${checkDeployedfile}"]).size() > 0) {
                                env.fileexists = true
                            } else {
                                env.fileexists = false
                            }
                        }

                    }
                }
            }


        }
    }
}
