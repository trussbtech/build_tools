/**
 * @author pdigum01* @Team IT-SCRM-Automation
 */


import bsc.scrmauto.jenkins.pipeline.*

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def ParseCommonVars = new ParseCommonVars()
    def Utils = new Utils()
    def GitUtils = new GitUtils()
    def Constants = new Constants()
    def ArtifactoryUtils = new ArtifactoryUtils()
    def sendNotification = new sendNotifications()
    def jiraSteps = new jiraSteps()
    def pipelinename = this.class.getName()

    def arr = config.buildenv
    def pollscm = "${config.Pollscm}"
    def jdkversion = "${config.jdkversion}"
    def mavenversion = "${config.mavenversion}"
    def mvngoals = "${config.mvngoals}"
    def artifacttype = "${config.artifacttype}"
    def mailRecipients = "${config.mailRecipients}"


    def rhelNode = 'rhel-node'

    def gitbranch
    def gituri
    def git_commit
    def git_previous_successful_commit
    def gitrevisionid
    def appname
    def compname
    def jiraVersion
    def properties
    def ZIP_TAG
    def buildVersion
    def jiraProjectKey
    def mvnbuildInfo

    pipeline {

        triggers {
            pollSCM("${pollscm}")
        }

        agent {
            node {
                label "jenkins-slave-centos"
            }
        }

        /*tools {
            maven "${mavenversion}"
            jdk "${jdkversion}"
        }*/

        options {
            skipDefaultCheckout(true)
            disableConcurrentBuilds()
            buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '10'))
        }


        stages {
            stage("Git clone") {
                steps {
                    deleteDir()
                    script {
                        //Utils.printEnv()
                        dir("${env.BRANCH_NAME}") {
                            def scmProp = checkout scm

                            git_commit = scmProp.GIT_COMMIT
                            git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
                            gitbranch = scmProp.GIT_BRANCH
                            gituri = scmProp.GIT_URL

                            // For PR gituri will be NULL
                            if (gituri) {
                                appname = ParseCommonVars.getAppname(gituri)
                                compname = ParseCommonVars.getCompname(gituri)
                                jiraVersion = "1.0.0"
                                jiraProjectKey = "sdm"
                                ZIP_TAG = appname + '-' + compname + '-' + "${jiraVersion}" + '.' + "${env.BUILD_ID}" + '.zip'
                                buildVersion = "${jiraVersion}" + '.' + "${env.BUILD_ID}"
                                //erm = jiraSteps.getERM(ParseCommonVars.getactualJiraVersion())
                                gitrevisionid = GitUtils.getRevisionID()

                            }
                        }
                        GitUtils.getChangelist()
                    }
                }
            }

            stage('Initialize') {
                steps {
                    sh """
                       echo copying ${JENKINS_ARTIFACT_TEMPLATE_ZIP}
                       cp ${JENKINS_ARTIFACT_TEMPLATE_ZIP} .
                       echo "PATH = ${PATH}"
                    """
                    script {
                        Utils.unzip("dist", "JenkinsArtifactTemplate.zip",)
                    }
                }
            }

            stage('Build') {
                steps {
                    script {
                        dir("${env.BRANCH_NAME}") {
                            sh """
                                cd sdm-client-base
                                docker build -t sdm-client-base .
                                mkdir -p ${WORKSPACE}/sdm-client-base/build
                                """
                            def id = sh(returnStdout: true, script: 'docker create sdm-client-base').trim()

                            sh """
                                docker cp $id:/usr/src/apps/sdm/sdm-client-base/build/. ${WORKSPACE}/sdm-client-base/build/
                                docker rm -v $id
                                docker rmi sdm-client-base
                               """
                        }
                    }

                }
            }

            /*stage("Artifactory Upload") {
                //Condition to ignore this stage for PR
                when {
                    expression {
                        !gitbranch.contains("PR-")
                    }
                }

                steps {
                    script {
                        sh """
                           cp ${env.BRANCH_NAME}/target/$compname.$artifacttype dist/du_full
                           """
                        echo "${ZIP_TAG}"
                        //zip dir: 'dist', glob: '', zipFile: "${ZIP_TAG}", archive: true
                        Utils.zip("dist", "${ZIP_TAG}", ".")
                        ArtifactoryUtils.Uploadartifact(gituri, gitbranch, jiraVersion, git_commit, ZIP_TAG, erm, mvnbuildInfo)
                        archiveArtifacts '*-*-*.zip,gitChangeList.txt'
                    }

                }
            }*/
        }

        post {
            always {
                script {

                    //Utils.printEnv()
                    recordIssues(tools: [pmdParser()])
                    step([$class: 'JUnitResultArchiver', testResults: '**/surefire-reports/*.xml', healthScaleFactor: 1.0, allowEmptyResults: true])
                    step([$class: 'CoberturaPublisher', autoUpdateHealth: false, autoUpdateStability: false, coberturaReportFile: '**/target/site/cobertura/coverage.xml', conditionalCoverageTargets: '70, 0, 0', failNoReports: false, failUnhealthy: false, failUnstable: false, lineCoverageTargets: '80, 0, 0', maxNumberOfBuilds: 0, methodCoverageTargets: '80, 0, 0', onlyStable: false, sourceEncoding: 'ASCII', zoomCoverageChart: false])
                    //Utils.InsertJenkinsDB("${pipelinename}", "${compname}", "${appname}", "${ZIP_TAG}", "${jiraVersion}", "${jiraProjectKey}", "${git_commit}", "${gitbranch}")
                    //sendNotification.notifypost("$mailRecipients")
                }

            }
            success {
                script {
                    jiraSteps.commentChangeIssueszip(jiraProjectKey, ZIP_TAG).each { jiraChange ->
                        jiraAddComment(idOrKey: jiraChange.id,
                                comment: jiraChange.comment,
                                failOnError: false,
                                site: "jira"
                                //auditLog: false
                        )
                    }
                    //jiraIssueUpdater(issueSelector: [$class: 'DefaultIssueSelector'])
                    echo "JOB COMPLETED SUCCESSFULLY"
                }
            }
        }
    }
}