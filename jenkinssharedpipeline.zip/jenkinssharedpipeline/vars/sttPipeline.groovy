#!/usr/bin/env groovy
import bsc.scrmauto.jenkins.pipeline.*

def runTestsEDI(testType, envName, pomFilePath){
    def ArtifactoryUtils = new ArtifactoryUtils()
    def ParseCommonVars = new ParseCommonVars()
    def CommonPipelineSteps = new CommonPipelineSteps()
    def envgituri
    def mvnbuildInfo
    def mvngoals = "clean test -X -Dtestng_xml=testng-${testType}.xml"

    envgituri = "https://bitbucket.bsc.bscal.com/scm/qesedi/envconfig.git"
    echo "Running STT EDI Tests.."
    dir("${env.BRANCH_NAME}") {
        dir('envconfig') {
            git branch: "master", credentialsId: 'jenkins-bitbucket-prod', url: envgituri
            ParseCommonVars.loadProperties("${envName}.properties")
            //INPUT_EDI_PATH = ParseCommonVars.getProperty('INPUT_EDI_PATH')
            env.ENVNAME = "${envName}"
            ENVNAME = ParseCommonVars.getProperty('ENVNAME')
            //echo "INPUT_EDI_PATH: ${INPUT_EDI_PATH}"
            echo "ENVNAME: ${ENVNAME}"
        }
        withCredentials([usernamePassword(credentialsId: 'FACETS_CRED', passwordVariable: 'FACETS_PASSWORD', usernameVariable: 'FACETS_USER'), usernamePassword(credentialsId: 'WPR_CRED', passwordVariable: 'WPR_PASSWORD', usernameVariable: 'WPR_USER')]) {
            try {
                mvnbuildInfo = ArtifactoryUtils.mvnbuild("maven-3.3.3", pomFilePath, mvngoals)
                echo "mvnBuildInfo: ${mvnbuildInfo}"
                echo "Inside the try block."
//                CommonPipelineSteps.postbuildscript()
            }  catch(e){
                echo "Inside the catch block"
                echo "error: ${e}"
//                CommonPipelineSteps.postbuildscript()
            }
            CommonPipelineSteps.postbuildscript()
        }

    }

    publishHTML(target: [allowMissing         : false,
                         alwaysLinkToLastBuild: false,
                         keepAll              : true,
                         reportDir            : "${env.BRANCH_NAME}/test-output/BSC-reports",
                         reportFiles          : "Report.html",
                         reportName           : "${testType}"])
    //step([$class: 'JUnitResultArchiver', testResults: '**/TEST-TestSuite.xml', healthScaleFactor: 1.0, allowEmptyResults: true])
    return mvnbuildInfo

}

def runTestsPortal(testType, envName, pomFilePath){
    def ArtifactoryUtils = new ArtifactoryUtils()
    def ParseCommonVars = new ParseCommonVars()
    def CommonPipelineSteps = new CommonPipelineSteps()
    def envgituri
    def mvnbuildInfo
    def mvngoals = "clean test -Dtestng_xml=testng-${testType}.xml"

    envgituri = "https://bitbucket.bsc.bscal.com/scm/qespvm/envconfig.git"

    dir("${env.BRANCH_NAME}") {
        dir('envconfig') {
            git branch: "master", credentialsId: 'jenkins-bitbucket-prod', url: envgituri
            ParseCommonVars.loadProperties("${envName}.properties")
        }
        mvnbuildInfo = ArtifactoryUtils.mvnbuild("maven-3.3.3", pomFilePath, mvngoals)

        CommonPipelineSteps.postbuildscript()
    }

    publishHTML(target: [allowMissing         : false,
                         alwaysLinkToLastBuild: false,
                         keepAll              : true,
                         reportDir            : "${env.BRANCH_NAME}/test-output/BSC-reports",
                         reportFiles          : "Report.html",
                         reportName           : "${testType}"])
    //step([$class: 'JUnitResultArchiver', testResults: '**/TEST-TestSuite.xml', healthScaleFactor: 1.0, allowEmptyResults: true])
    return mvnbuildInfo

}


def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def ParseCommonVars = new ParseCommonVars()
    def Utils = new Utils()
    def GitUtils = new GitUtils()
    def Constants = new Constants()
    def jenkinsUtils = new jenkinsUtils()
    def ArtifactoryUtils = new ArtifactoryUtils()
    def CommonPipelineSteps = new CommonPipelineSteps()
    def sendNotification = new sendNotifications()
    def pipelinename = this.class.getName()

    def pollscm = "${config.Pollscm}"
    def mailRecipients = "${config.mailRecipients}"
    //def testType = "${config.testType}"


    def slave = 'windows-node-dev'
    def KATALON = 'E:\\Katalon\\katalon.exe'
    def mavenversion='3.2.3'

    def gitbranch
    def gituri
    def git_commit
    def git_previous_successful_commit
    def gitrevisionid
    def appname
    def compname
    def jiraVersion
    def properties
    def ZIP_TAG
    def envlist
    def buildVersion
    def jiraProjectKey
    def now
    def exists = false
    def findFile
    def mvnbuildInfo
    env.mvndeploy = false


    pipeline {

        /*triggers {
            pollSCM("${pollscm}")
        }*/

        agent {
            node {
                label "${slave}"
            }
        }

        tools{
            maven 'maven-3.3.3'
            jdk 'jdk1.8.0_20'
        }

        environment {
            KATALON = "E:\\Katalon\\katalon.exe"
        }

        options {
            skipDefaultCheckout(true)
            disableConcurrentBuilds()
            buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '5'))
            //lock(resource: 'AndriodBuild', inversePrecedence: true)
        }

        parameters {
            choice(
                    name: 'Environment',
                    choices: "releasetest\nopstest\nuat1\nuat2\nqa1\nqa2\nbreakfix",
                    description: 'type of environment'
            )
            choice(name: 'TestType',
                    choices: "smokeTest\nfunctionalTest\nregressionTest",
                    description: 'types of tests')
        }

        stages {
            stage('Git clone') {
                steps {
                    deleteDir()
                    script {

                        dir("${env.BRANCH_NAME}") {

                            def scmProp = checkout scm

                            git_commit = scmProp.GIT_COMMIT
                            git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
                            gitbranch = scmProp.GIT_BRANCH
                            gituri = scmProp.GIT_URL
                            testType = params.TestType
                            envName = params.Environment
                            now = new Date()
                            String time = now.format("yyyy-MM-dd-HH-mm", TimeZone.getTimeZone('PST'))
                            // For PR gituri will be NULL
                            if (gituri) {

                                appname = ParseCommonVars.getAppname(gituri)
                                compname = ParseCommonVars.getCompname(gituri)
                                jiraVersion = ParseCommonVars.getJiraVersion()
                                jiraProjectKey = ParseCommonVars.getJiraKey()
                                ZIP_TAG = time + '.zip'
                                buildVersion = "${jiraVersion}" + '.' + "${env.BUILD_ID}"
                                gitrevisionid = GitUtils.getRevisionID()
                                GitUtils.getChangelist(git_commit, git_previous_successful_commit)

                            }
                            CommonPipelineSteps.prebuildscript()
                        }
                        currentBuild.description = "${params.TestType}" + '-' + "${params.Environment}"
                        currentBuild.displayName = '#' + "${buildVersion}"


                        //If workspace contains pom.xml, run Web Services test command else Katalon command
                        def workspace = pwd()
                        findFile = workspace+"\\${env.BRANCH_NAME}\\pom.xml"
                        exists = fileExists findFile
                        echo "Checking if pom.xml exists in file path..${exists}"
                        echo "GIT URI is: ${gituri}"


                    }
                }
            }

            stage('SmokeTest') {
                when {
                    expression { params.TestType == "smokeTest" }
                }

                steps {
                    timeout(time: 12, unit: 'MINUTES') {
                        script {
                            if (exists == true) {
                                if (gituri.toLowerCase().contains("qespvm")) {
                                    echo "Running portal build"
                                    mvnbuildinfo = runTestsPortal("smoketest", params.Environment, findFile)
                                } else if ((gituri.toLowerCase().contains("qesedi")) || (gituri.toLowerCase().contains("qesfac"))){
                                    echo "Running edi/facets stt build"
                                    mvnbuildinfo = runTestsEDI("smoketest", params.Environment, findFile)
                                    echo "mvnbuildinfo from SmokeTest: ${mvnbuildinfo}"
                                }

//                                CommonPipelineSteps.postbuildscript()

                            }
                        }
                    }
                }
            }

            stage('FunctionalTest') {
                when {
                    expression { params.TestType == "functionalTest" }
                }
                steps {
                    timeout(time: 60, unit: 'MINUTES') {
                        script {
                            if (exists == true) {
                                if (gituri.toLowerCase().contains("qespvm")) {
                                    echo "Running portal build"
                                    mvnbuildinfo = runTestsPortal("functional", params.Environment, findFile)
                                } else if ((gituri.toLowerCase().contains("qesedi")) || (gituri.toLowerCase().contains("qesfac"))){
                                    echo "Running edi stt build"
                                    mvnbuildinfo = runTestsEDI("smoketest", params.Environment, findFile)
                                }

//                                    CommonPipelineSteps.postbuildscript()

                            }
                        }
                    }
                }
            }

            stage('RegressionTest') {
                when {
                    expression { params.TestType == "regressionTest" }
                }
                steps {
                    timeout(time: 180, unit: 'MINUTES') {
                        script {
                            if (exists == true) {
                                if (gituri.toLowerCase().contains("qespvm")) {
                                    echo "Running portal build"
                                    mvnbuildinfo = runTestsPortal("regression", params.Environment, findFile)
                                } else if ((gituri.toLowerCase().contains("qesedi")) || (gituri.toLowerCase().contains("qesfac"))) {
                                    echo "Running edi stt build"
                                    mvnbuildinfo = runTestsEDI("regression", params.Environment, findFile)
                                }
//                                        CommonPipelineSteps.postbuildscript()
                            }
                        }
                    }

                }
            }
        }

        post {
            always {
                recordIssues aggregatingResults: true, enabledForFailure: true, tools: [pmdParser(pattern: '**/pmd.xml')]
                step([$class: 'JUnitResultArchiver', testResults: '**/Reports/*-*/JUnit_Report.xml', healthScaleFactor: 1.0, allowEmptyResults: true])
                //step([$class: 'JUnitResultArchiver', testResults: '**/TEST-TestSuite.xml', healthScaleFactor: 1.0, allowEmptyResults: true])
                script {

                    Utils.zip("${env.BRANCH_NAME}//Reports", "${ZIP_TAG}", ".")
                    Utils.zip("${env.BRANCH_NAME}//test-output//BSC-reports/", "${ZIP_TAG}", ".")
                    ArtifactoryUtils.UploadqeTestReports(gituri, gitbranch, jiraVersion, params.TestType, git_commit, params.Environment, mvnbuildInfo)
                    Utils.InsertJenkinsDB("${pipelinename}", "${compname}", "${appname}", "${ZIP_TAG}", "${jiraVersion}", "${jiraProjectKey}", "${git_commit}", "${gitbranch}")

                }

            }
            success {
                //jiraIssueUpdater(issueSelector: [$class: 'DefaultIssueSelector'])
                echo "JOB COMPLETED SUCCESSFULLY"
            }
        }
    }
}
