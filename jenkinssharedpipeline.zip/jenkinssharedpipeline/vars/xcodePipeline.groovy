#!/usr/bin/env groovy
import bsc.scrmauto.jenkins.pipeline.*

def runbuild(env) {
    stage("Build: ${env}") {
        echo "Running ${env} build..."
        withCredentials([string(credentialsId: 'ZIPPWD', variable: 'ZIPPWD')]) {
            ansiColor('xterm') {
                sh """
                        sh jenkinsbuildscript.sh ${env}
                    """
            }
        }
    }
}
def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def ParseCommonVars = new ParseCommonVars()
    def Utils = new Utils()
    def GitUtils = new GitUtils()
    def Constants = new Constants()
    def appCenterUserAPItoken = Constants.appCenterUserAPItoken
    def NexusUtils = new NexusUtils()
    def jiraSteps = new jiraSteps()
    def ArtifactoryUtils = new ArtifactoryUtils()
    def sendNotification = new sendNotifications()
    def pipelinename = this.class.getName()

    def pollscm = "${config.Pollscm}"
    def xcodeversion = "${config.xcodeversion}"
    def buildipas = config.buildipas
    def IOS_SIMULATOR_VERSION = config.IOS_SIMULATOR_VERSION
    def IOS_SIMULATOR_NAME = config.IOS_SIMULATOR_NAME
    def appCenter_appName = "${config.appCenter_appName}"
    def hockey_app_file = "${config.hockey_app_file}"
    def mailRecipients = "${config.mailRecipients}"
    def appVersion = "${config.appVersion}"


    def developer_dir = "/Applications/" + xcodeversion + ".app/Contents/Developer"
    def slave = 'build-mac'

    def gitbranch
    def gituri
    def git_commit
    def git_previous_successful_commit
    def gitrevisionid
    def appname
    def compname
    def jiraVersion
    def erm
    def ZIP_TAG
    def envlist
    def buildVersion
    def jiraProjectKey

    pipeline {

        triggers {
            pollSCM("#${pollscm}")
        }

        agent {
            node {
                label "${slave}"
            }
        }

        options {
            skipDefaultCheckout(true)
            disableConcurrentBuilds()
            buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '3'))
        }

        environment {
            DEVELOPER_DIR = "${developer_dir}"
            NEXUSARTIFACTLIMIT = 6
            KEKAZIP = "/Applications/Keka.app/Contents/Resources/keka7z"
            PATH = "/bin:/usr/local/bin:/usr/bin:/usr/sbin:/sbin:$PATH"
            SIMULATOR_VERSION = "${IOS_SIMULATOR_VERSION}"
            SIMULATOR_NAME = "${IOS_SIMULATOR_NAME}"
        }


        stages {

            stage('Git clone') {
                steps {
                    deleteDir()
                    script {

                        dir("${env.BRANCH_NAME}") {

                            def scmProp = checkout scm

                            git_commit = scmProp.GIT_COMMIT
                            git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
                            gitbranch = scmProp.GIT_BRANCH
                            gituri = scmProp.GIT_URL

                            // For PR gituri will be NULL
                            if (gituri) {

                                appname = ParseCommonVars.getAppname(gituri)
                                compname = ParseCommonVars.getCompname(gituri)
                                jiraVersion = ParseCommonVars.getJiraVersion()
                                jiraProjectKey = ParseCommonVars.getJiraKey()
                                env.erm = jiraSteps.getERM(ParseCommonVars.getactualJiraVersion())
                                ZIP_TAG = appname + '-' + compname + '-' + "${appVersion}" + '.' + "${env.BUILD_ID}" + '.zip'
                                buildVersion = "${appVersion}" + '.' + "${env.BUILD_ID}"
                                gitrevisionid = GitUtils.getRevisionID()


                            }
                        }
                        GitUtils.getChangelist()
                        Utils.getartifacttemplate()
                    }
                }
            }


            stage('Build and Unit Test') {
                when {
                    expression {
                        !gitbranch.contains("demo/")
                    }
                }
                steps {
                    lock(resource: "${env.SIMULATOR_NAME}", inversePrecedence: true) {
                        dir("${env.BRANCH_NAME}") {
                            sh """
                            rm -rf "/Users/buildadm/Library/Developer/Xcode/DerivedData"
                            rm -rf "~/Library/Developer/Xcode/*"
                            rm -rf "/Users/buildadm/Library/Developer/CoreSimulator/Devices/*"
                            #killall "Simulator" || true
                            /usr/bin/xcodebuild -version
                            sh jenkinsbuildscript.sh "unit-test"
                            #killall "Simulator" || true
                        """
                            step([$class: 'JUnitResultArchiver', testResults: '**/test-reports/*.xml', healthScaleFactor: 1.0, allowEmptyResults: true])
                        }
                    }
                }
            }

            stage('Static Analysis') {
                when {
                    expression {
                        !gitbranch.contains("demo/")
                    }
                }
                steps {
                    parallel(
                            Coverage: {
                                dir("${env.BRANCH_NAME}") {
                                    // Generate Code Coverage report
                                    sh """
                                        cd "${WORKSPACE}/${BRANCH_NAME}"
                                        pwd
                                        #slather
                                    """
                                }
                                // Publish coverage results
                                //cobertura autoUpdateHealth: false, autoUpdateStability: false, coberturaReportFile: '**/cobertura-reports/cobertura.xml', conditionalCoverageTargets: '70, 0, 0', failUnhealthy: false, failUnstable: false, lineCoverageTargets: '80, 0, 0', maxNumberOfBuilds: 0, methodCoverageTargets: '80, 0, 0', onlyStable: false, sourceEncoding: 'ASCII', zoomCoverageChart: false
                                //cobertura autoUpdateHealth: false, autoUpdateStability: false, coberturaReportFile: '**/cobertura-reports/cobertura.xml', lineCoverageTargets: '40, 0, 0', maxNumberOfBuilds: 0, onlyStable: false, sourceEncoding: 'ASCII', zoomCoverageChart: false
                            },
                            Checkstyle: {
                                dir("${env.BRANCH_NAME}") {
                                    // Generate Checkstyle report
                                    sh "/usr/local/bin/swiftlint lint --reporter checkstyle > checkstyle.xml || true"
                                    //echo "testing"
                                }
                                // Publish checkstyle result
                                recordIssues aggregatingResults: true, tools: [swiftLint(pattern: '**/checkstyle.xml')]
                            }
                    )
                }
            }

            stage("Initialize") {
                steps {
                    script {
                        if (!gitbranch.contains("PR-")) {
                            dir("${env.BRANCH_NAME}") {
                                ansiColor('xterm') {
                                    withEnv(["POM_VERSION=${appVersion}"]) {
                                        for (int i = 0; i < buildipas.size(); i++) {
                                            runbuild(buildipas[i])
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            stage("Publish artifact") {
                when {
                    expression {
                        !gitbranch.contains("PR-")
                    }
                }

                steps {

                    parallel(
                            Artifactory: {
                                script {
                                    Utils.copy("${env.BRANCH_NAME}", "dist/du_full", "**/*.ipa", "**/*prod.ipa")
                                    Utils.copy("${env.BRANCH_NAME}", "dist/du_full", "**/prod-secure.zip")
                                    Utils.copy("${env.BRANCH_NAME}", "dist/du_full", "**/*.bca")
                                    Utils.zip("dist", "${ZIP_TAG}", ".")
                                    //Utils.printEnv()
                                    //NexusUtils.Uploadartifact("${appname}", "${compname}", "${jiraVersion}", "${ZIP_TAG}")
                                    ArtifactoryUtils.Uploadartifactmobile(gituri, gitbranch, appVersion, git_commit, ZIP_TAG, erm)
                                    archiveArtifacts '*-*-*.zip,gitChangeList.txt'
                                }
                            },
                            AppCenter: {

                                script {
                                    echo "Need to add Appcenter"
                                    appCenter apiToken: appCenterUserAPItoken,
                                                appName: "${appCenter_appName}",
                                                distributionGroups: "BSC_Testers",
                                                notifyTesters: true,
                                                ownerName: 'blueshieldofcalifornia',
                                                pathToApp: "**/${hockey_app_file}",
                                                releaseNotes: ''

                                    //apiToken          : "${appCenterUserAPItoken}"
                                    //                                hockeyApp applications: [[apiToken          : "${appCenterUserAPItoken}",
                                    //                                                          downloadAllowed   : true,
                                    //                                                          filePath          : "**/${hockey_app_file}",
                                    //                                                          mandatory         : true,
                                    //                                                          notifyTeam        : true,
                                    //                                                          oldVersionHolder  : [numberOldVersions: '10', sortOldVersions: 'version', strategyOldVersions: 'soft'],
                                    //                                                          releaseNotesMethod: changelog(),
                                    //                                                          uploadMethod      : versionCreation(appId: "${hockey_appid}", versionCode: '')]]
                                }
                            }

                    )


                }

            }
        }

        post {
            always {
                node('rhel-node') {
                    script {
                        Utils.InsertJenkinsDB("${pipelinename}", "${compname}", "${appname}", "${ZIP_TAG}.zip", "${jiraVersion}", "${jiraProjectKey}", "${git_commit}", "${gitbranch}","${env.erm}")
                        sendNotification.notifypost("$mailRecipients")
                    }

                }

            }
            success {
                script {
                    jiraSteps.commentChangeIssueszip(jiraProjectKey, ZIP_TAG).each { jiraChange ->
                        jiraAddComment(idOrKey: jiraChange.id,
                                comment: jiraChange.comment,
                                failOnError: false,
                                site: "jira"
                                //auditLog: false
                        )
                    }
                    echo "JOB COMPLETED SUCCESSFULLY"
                }

            }
        }


    }
}