#!/usr/bin/env groovy

import bsc.scrmauto.jenkins.pipeline.*

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def ParseCommonVars = new ParseCommonVars()
    def CommonPipelineSteps = new CommonPipelineSteps()
    def Utils = new Utils()
    def GitUtils = new GitUtils()
    def Constants = new Constants()
    def ArtifactoryUtils = new ArtifactoryUtils()
    def sendNotification = new sendNotifications()
    def jiraSteps = new jiraSteps()
    def jenkinsutils = new jenkinsUtils()
    def pipelinename = this.class.getName()



    def pollscm = "${config.Pollscm}"
    def mailRecipients = "${config.mailRecipients}"


    def slave = 'rhel-node'
    //    def slave = 'windows-node'

    def gitbranch
    def gituri
    def git_commit
    def git_previous_successful_commit
    def gitrevisionid
    def appname
    def compname
    def jiraVersion
    def properties
    def ZIP_TAG
    def buildNumber = env.BUILD_NUMBER


    pipeline {

        triggers {
            pollSCM("${pollscm}")
        }

        agent {
            node {
                label "${slave}"
            }
        }

        options {
            skipDefaultCheckout(true)
            disableConcurrentBuilds()
            buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '10'))
        }


        stages {

            stage("Git clone") {
                steps {
                    deleteDir()
                    script {
                        //Utils.printEnv()

                        dir("${env.BRANCH_NAME}") {
                            def scmProp = checkout scm

                            env.git_commit = scmProp.GIT_COMMIT
                            env.git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
                            env.gitbranch = scmProp.GIT_BRANCH
                            env.gituri = scmProp.GIT_URL
                            //echo "{$env.gituri}"
                            // For PR gituri will be NULL
                            if (!env.CHANGE_ID) {
                                jenkinsutils.abortFirstbuild()
                                env.appname = ParseCommonVars.getAppname(env.gituri)
                                env.compname = ParseCommonVars.getCompname(env.gituri)
                                env.jiraVersion = ParseCommonVars.getJiraVersion()
                                env.jiraProjectKey = ParseCommonVars.getJiraKey()
                                env.ZIP_TAG = env.appname + '-' + env.compname + '-' + "${env.jiraVersion}" + '.' + "${env.BUILD_ID}" + '.zip'
                                env.buildVersion = "${env.jiraVersion}" + '.' + "${env.BUILD_ID}"
                                env.erm = jiraSteps.getERM(ParseCommonVars.getactualJiraVersion())
                                env.gitrevisionid = GitUtils.getRevisionID()
                                ArtifactoryUtils.CheckIsThisProdFixVersion(env.gituri,env.jiraVersion)

                            }
                        }
                        GitUtils.getChangelist()
                    }
                }
            }

            stage("Initialize build") {
                steps {
                    sh """
                       echo copying ${JENKINS_ARTIFACT_TEMPLATE_ZIP}
                       cp ${JENKINS_ARTIFACT_TEMPLATE_ZIP} .
                    """
                    script {
                        Utils.unzip("dist", "JenkinsArtifactTemplate.zip",)
                    }
                }

            }


            stage("Incremental build") {
                steps {
                    script{
                        dir("${env.BRANCH_NAME}") {
                            CommonPipelineSteps.prebuildscript()
                            sh "${PYTHON} ${GIT_INCREMENTAL_BUILD} --path ${WORKSPACE}/${BRANCH_NAME} --jiraVersion $env.jiraVersion --buildNumber ${BUILD_ID} --compName $env.compname --appName $env.appname"
                            CommonPipelineSteps.postbuildscript()
                        }

                    }

                }
            }

            stage("Artifactory Upload") {

                steps {
                    script {
                        echo "${env.ZIP_TAG}"
                        Utils.zip("dist", "${env.ZIP_TAG}", ".", "**/component.properties,**/Jenkinsfile,**/prebuild.sh,**/postbuild.sh")
                        ArtifactoryUtils.Uploadartifact(env.gituri, env.gitbranch, env.jiraVersion, env.git_commit, env.ZIP_TAG, env.erm)
                        archiveArtifacts '*-*-*.zip,gitChangeList.txt'
                    }

                }
            }
        }

        post {
            always {
                script {
                    echo "sending email"
                    Utils.InsertJenkinsDB("${pipelinename}", "${env.compname}", "${env.appname}", "${env.ZIP_TAG}.zip", "${env.jiraVersion}", "${env.jiraProjectKey}", "${env.git_commit}", "${env.gitbranch}", "${env.erm}")
                    sendNotification.notifypost("$mailRecipients")
                }

            }
            success {
                script {
                    if (!env.CHANGE_ID) {
                        jiraSteps.commentChangeIssueszip(env.jiraProjectKey, env.ZIP_TAG).each { jiraChange ->
                            jiraAddComment(idOrKey: jiraChange.id,
                                    comment: jiraChange.comment,
                                    failOnError: false,
                                    site: "jira"
                                    //auditLog: false
                            )
                        }
                    }
                    //jiraIssueUpdater(issueSelector: [$class: 'DefaultIssueSelector'])
                    echo "JOB COMPLETED SUCCESSFULLY"
                }
            }
        }
    }
}