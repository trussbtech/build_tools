#!/usr/bin/env groovy
/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */

import bsc.scrmauto.jenkins.pipeline.GitUtils
import bsc.scrmauto.jenkins.pipeline.sendNotifications

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def GitUtils = new GitUtils()
    def sendNotification = new sendNotifications()

    def pollscm = "${config.Pollscm}"
    def mailRecipients = "${config.mailRecipients}"


    def slave = 'deploy-puppet'
    def r10k = '/opt/puppetlabs/puppet/bin/r10k'
    def appserver = 'puppet.bsc.bscal.com'


    pipeline {

        /*triggers {
            pollSCM("${pollscm}")
        }*/

        agent {
            node {
                label "${slave}"
            }
        }

        options {
            skipDefaultCheckout(true)
            disableConcurrentBuilds()
            buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '10'))
            ansiColor('xterm')
        }

        stages {

            stage("Git clone") {
                steps {
                    deleteDir()
                    script {
                        //Utils.printEnv()
                        dir("${env.BRANCH_NAME}") {
                            def scmProp = checkout scm

                            git_commit = scmProp.GIT_COMMIT
                            git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
                            gitbranch = scmProp.GIT_BRANCH
                            gituri = scmProp.GIT_URL

                            //GitUtils.getChangelist(git_commit, git_previous_successful_commit)

                            currentBuild.description = "${gitbranch}"
                        }
                        GitUtils.getChangelist()
                    }
                }
            }

            stage ("Deploy") {
                steps{
                    script {
                        withCredentials([usernamePassword(credentialsId: 'unixbuildadmpass', passwordVariable: 'passWord', usernameVariable: 'userName')]) {

                            sh """
                                #!/bin/bash
                                sshpass -p${passWord} ssh -o StrictHostKeyChecking=no buildadm@${appserver} <<EOF
                                    sudo su - puppet
                                    ${r10k} deploy environment ${gitbranch} -p -v -t --color
                                    echo Running puppet generate types ...
                                    puppet generate types --environment ${gitbranch} --force --environmentpath /etc/puppetlabs/puppet/environments
                                EOF
                            """.stripIndent()

                        }
                        archiveArtifacts 'gitChangeList.txt'
                    }
                }

            }

        }

        post {
            always {
                script {

                    //echo "${mailRecipients}"
                    sendNotification.notifypost("$mailRecipients")
                }

            }
            success {
                //jiraIssueUpdater(issueSelector: [$class: 'DefaultIssueSelector'])
                echo "JOB COMPLETED SUCCESSFULLY"
            }
        }
    }

}