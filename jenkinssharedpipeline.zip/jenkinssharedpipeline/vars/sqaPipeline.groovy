#!/usr/bin/env groovy
import bsc.scrmauto.jenkins.pipeline.*

def triggerTest(testType, compname, envName, browser) {
    def Utils = new Utils()
    def workspace = pwd()
    findKatalonFile = workspace+"//${env.BRANCH_NAME}//katalon_command.bat"
//    exists = fileExists findKatalonFile
    def exists = fileExists findKatalonFile
    def API_KEY = "${env.KATALON_API_KEY}"
    println("API_KEY = {$API_KEY}")
    println("BRANCH_NAME = ${env.BRANCH_NAME}")
    env.PROJECT_PATH = workspace+"//${env.BRACH_NAME}"
    env.TEST_TYPE = "${testType}"
    env.BROWSER = "${browser}"
    env.COMPNAME = "${compname}"
    env.KATALON = "${env.KATALON}"
    println("KATALON PATH: ${env.KATALON}")
    println("BROWSER: ${env.BROWSER}")
    println("COMPNAME: ${env.COMPNAME}")

    def readts = readFile file: "${env.WORKSPACE}\\${env.BRANCH_NAME}\\Test Suites\\Parallel Test Suites\\${testType}.ts"
    readts = readts.replaceAll("<profileName>.*<\\/profileName>", "<profileName>${envName}</profileName>")
    writeFile file: "${env.WORKSPACE}\\${env.BRANCH_NAME}\\Test Suites\\Parallel Test Suites\\${testType}.ts", text: readts

    if (exists) {
        echo 'Yes..RUNNING KATALON BATCH FILE NOW...'
        dir("${env.BRANCH_NAME}") {
            bat ('call katalon_command.bat')
        }

    } else {
        echo 'No katalon command to run'
    }

//    def readts = readFile file: "${env.WORKSPACE}\\${env.BRANCH_NAME}\\Test Suites\\Parallel Test Suites\\${testType}.ts"
//    readts = readts.replaceAll("<profileName>.*<\\/profileName>", "<profileName>${envName}</profileName>")
//    writeFile file: "${env.WORKSPACE}\\${env.BRANCH_NAME}\\Test Suites\\Parallel Test Suites\\${testType}.ts", text: readts



//    bat """
//            echo Running Katalon Tests
//            %KATALON% -runMode=console -projectPath="%WORKSPACE%\\${env.BRANCH_NAME}\\${
//        compname
//    }.prj" -retry=0 -testSuiteCollectionPath="Test Suites\\Parallel Test Suites\\${testType}" -apiKey=fadeae98-63e7-4f16-aaad-155bd970dc05 -executionProfile="${envName}" -reportFolder="Reports\\${
//        browser
//    }-${
//        testType
//    }" -reportFileName="${browser}-${testType}"
//
//        REM exit /b 0
//        """
//    bat """
//            echo Running Katalon Tests
//
//             E:\\Katalon\\Katalon_Studio_Engine_Windows_721\\katalonc -noSplash -runMode=console -projectPath="C:\\Users\\svcjenkins\\Katalon Studio\\SampleTestProjectWeb.prj" -retry=0 -testSuiteCollectionPath="Test Suites/smokeTest" -apiKey="33ac1b2b-a8c5-4b78-8d81-15a7d2960a95"
//        REM exit /b 0
//        """
//For parallel RUNS on NEW KATALON RUNTIME ENGINE
//    katalonc -noSplash -runMode=console -projectPath="C:\work\SCRM_D\Automation\sandbox\test_katalon\SampleTestProjectWeb.prj" -retry=0 -testSuiteCollectionPath="Test Suites/smokeTest" -apiKey="9d7ed467-59ed-465f-9c0c-19676c0e80fe"
//    %KATALON% -noSplash -runMode=console -projectPath="C:\\Users\\svcjenkins\\Katalon Studio\\SampleTestProjectWeb.prj" -retry=0 -testSuitePath="Test Suites/smokeTest" -executionProfile="default" -browserType="Chrome" -apiKey="33ac1b2b-a8c5-4b78-8d81-15a7d2960a95"

//    katalon -noSplash  -runMode=console -consoleLog -noExit -projectPath="D:\Automation\web\csadmin\csadmin.prj" -statusDelay=3 -retry=0 -testSuiteCollectionPath="Test Suites/regressionTest"

//    publishHTML(target: [
//            allowMissing         : false,
//            alwaysLinkToLastBuild: false,
//            keepAll              : true,
//            reportDir            : "${env.BRANCH_NAME}/Reports/${browser}-${testType}",
//            //reportFiles          : "${browser}-${testType}.html",
//            reportName           : "${browser}-${testType}"
//    ])
   // step([$class: 'JUnitResultArchiver', testResults: "**/Reports/${browser}-${testType}/*/JUnit_Report.xml", healthScaleFactor: 1.0, allowEmptyResults: true])

}


def runTests(testType, compname, envName) {
    slavetoRun = 'msbuild2017'
    echo "Running ${testType} build for portal..."
    triggerTest(testType, compname, envName, "Chrome")
    /*parallel(
            'Chrome': {
                    triggerTest(testType, compname, envName, "Chrome")
            },
            'Firefox': {
                node("${slavetoRun}") {
                    deleteDir()
                    dir("${env.BRANCH_NAME}") {
                        checkout scm
                    }
                    triggerTest(testType, compname, envName, "Firefox")
                    stash includes: "${env.BRANCH_NAME}/Reports/Firefox-${testType}/*", name: 'firefoxreports', allowEmpty: true
                }

            }
    )*/
}

def runTestsServices(testType, compname, envName, pomFilePath){
    def ArtifactoryUtils = new ArtifactoryUtils()
    def ParseCommonVars = new ParseCommonVars()
    def envgituri
    def mvnbuildInfo
    def portUri
    env.mvngoals = "clean test -Dtestng_xml=testng-${testType}.xml -Dmaven.javadoc.skip=true -U -B"
    def gituri = scm.getUserRemoteConfigs()[0].getUrl()


    echo "Running web services build .. inside runtests"
    envgituri = "https://bitbucket.bsc.bscal.com/scm/ase/envconfig.git"
    portUri = "https://bitbucket.bsc.bscal.com/scm/ase/port.git"
    dir("${env.BRANCH_NAME}") {
        dir('envconfig') {
            git branch: "master", credentialsId: 'jenkins-bitbucket-prod', url: envgituri
            ParseCommonVars.loadProperties("${envName}.properties")
        }
        dir('port') {
            git branch: "master", credentialsId: 'jenkins-bitbucket-prod', url: portUri
            findFile = "${compname}.properties"
            exists = fileExists findFile
            echo("${compname}.properties file exists...${exists}")
            if (exists == true) {
                ParseCommonVars.loadProperties("${compname}.properties")
                echo "loaded ${compname}.properties file and ${envName}.properties"
                envURL = ParseCommonVars.getProperty('ENVURL')
//                echo "envURL: ${envURL}"
                if (env.ESB_PORT){
                    esb_port = ParseCommonVars.getProperty('ESB_PORT')
//                    echo "esb_port: ${esb_port}"
                    env.ENVURL = "${envURL}:${esb_port}"
//                    echo "appended ESB_PORT to ENVURL, it is now: ${env.ENVURL}"
                } else {
                    env.ENVURL = "${envURL}"
                }

                env.ENVNAME = "${envName}"
                echo "ENVNAME property: ${ParseCommonVars.getProperty('ENVNAME')}"
                echo "ENVURL property: ${ParseCommonVars.getProperty('ENVURL')} "
//                env.getEnvironment().each { name, value -> println "Name: $name -> Value $value" }

            } else {
                env.ENVNAME = "${envName}"
                env.ENVURL = "${envURL}"
                echo env.ENVURL
                echo("This web service has no port properties it will NOT run...ABORT")
                return
            }
        }
    }

    dir("${env.BRANCH_NAME}") {

        withCredentials([usernamePassword(credentialsId: 'FACETS_CRED', passwordVariable: 'FACETS_PASSWORD', usernameVariable: 'FACETS_USER'),
                         usernamePassword(credentialsId: 'WPR_CRED', passwordVariable: 'WPR_PASSWORD', usernameVariable: 'WPR_USER'),
                         usernamePassword(credentialsId: 'PHX_CRED', passwordVariable: 'PHXDB_PASSWORD', usernameVariable: 'PHXDB_USER')
        ]) {
            mvnbuildInfo = ArtifactoryUtils.mvnbuild("maven-3.3.3", pomFilePath, env.mvngoals)
        }


    }

    publishHTML(target: [allowMissing         : false,
                         alwaysLinkToLastBuild: false,
                         keepAll              : true,
                         reportDir            : "${env.BRANCH_NAME}/test-output/BSC-reports",
                         reportFiles          : "Report.html",
                         reportName           : "${testType}"])
        //step([$class: 'JUnitResultArchiver', testResults: '**/TEST-TestSuite.xml', healthScaleFactor: 1.0, allowEmptyResults: true])
    return mvnbuildInfo
}

def runTestsPortal(testType, envName, pomFilePath){
    def ArtifactoryUtils = new ArtifactoryUtils()
    def ParseCommonVars = new ParseCommonVars()
    def envgituri
    def mvnbuildInfo
    env.mvngoals = "clean test -U -B -Dtestng_xml=testng-${testType}.xml -Dmaven.javadoc.skip=true"

    envgituri = "https://bitbucket.bsc.bscal.com/scm/qespvm/envconfig.git"

    dir("${env.BRANCH_NAME}") {
        dir('envconfig') {
            git branch: "master", credentialsId: 'jenkins-bitbucket-prod', url: envgituri
            ParseCommonVars.loadProperties("${envName}.properties")
        }


        //mvnbuildInfo = ArtifactoryUtils.mvnbuild("maven-3.3.3", pomFilePath, mvngoals)

        withCredentials([usernamePassword(credentialsId: 'FACETS_CRED', passwordVariable: 'FACETS_PASSWORD', usernameVariable: 'FACETS_USER'),
                         usernamePassword(credentialsId: 'WPR_CRED', passwordVariable: 'WPR_PASSWORD', usernameVariable: 'WPR_USER'),
                         usernamePassword(credentialsId: 'PHX_CRED', passwordVariable: 'PHXDB_PASSWORD', usernameVariable: 'PHXDB_USER'),
                         usernamePassword(credentialsId: 'DENODO_CRED', passwordVariable: 'DENODO_PASSWORD', usernameVariable: 'DENODO_USER')

        ]) {
            mvnbuildInfo = ArtifactoryUtils.mvnbuild("maven-3.3.3", pomFilePath, env.mvngoals)
        }

    }

    publishHTML(target: [allowMissing         : false,
                         alwaysLinkToLastBuild: false,
                         keepAll              : true,
                         reportDir            : "${env.BRANCH_NAME}/test-output/BSC-reports",
                         reportFiles          : "Report.html",
                         reportName           : "${testType}"])
    //step([$class: 'JUnitResultArchiver', testResults: '**/TEST-TestSuite.xml', healthScaleFactor: 1.0, allowEmptyResults: true])

    return mvnbuildInfo

}


def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def ParseCommonVars = new ParseCommonVars()
    def Utils = new Utils()
    def GitUtils = new GitUtils()
    def Constants = new Constants()
    def jenkinsUtils = new jenkinsUtils()
    def ArtifactoryUtils = new ArtifactoryUtils()

    def sendNotification = new sendNotifications()
    def pipelinename = this.class.getName()

    def pollscm = "${config.Pollscm}"
    def mailRecipients = "${config.mailRecipients}"
    //def testType = "${config.testType}"


    def slave = 'qetest'
//    def KATALON = 'E:\\Katalon\\katalon.exe'
//    def KATALON = 'E:\\Katalon\\Katalon_Studio_Engine_Windows_721\\katalonc'
    def mavenversion='3.2.3'

    def gitbranch
    def gituri
    def git_commit
    def git_previous_successful_commit
    def gitrevisionid
    def appname
    def compname
    def jiraVersion
    def properties
    def ZIP_TAG
    def envlist
    def buildVersion
    def jiraProjectKey
    def now
    def exists = false
    def findFile
    def mvnbuildInfo
    env.mvndeploy = false

//    def AGENT_LABEL = null
//
//    node('qetest') {
//        stage('set agent'){
//            def scmUrl = scm.getUserRemoteConfigs()[0].getUrl()
//            println("SCM URL is: ${scmUrl}")
//            component_name = ParseCommonVars.getCompname(scmUrl)
//            println("Component Name: ${component_name}")
//            search = "katalon"
//            if ( component_name.toLowerCase().indexOf("katalon".toLowerCase()) != -1 ) {
//
//                println("This is a Katalon project");
//                AGENT_LABEL = "msbuild2017"
//
//            } else {
//
//                println("this is NOT a Katalon");
//                AGENT_LABEL = "${slave}"
//            }
//        }
//    }


    pipeline {

        /*triggers {
            pollSCM("${pollscm}")
        }*/

        agent {
            node {

                label "${slave}"
            }
        }

        tools{
            maven 'maven-3.3.3'
            jdk 'jdk1.8.0_20'
        }

        environment {
//            KATALON = "E:\\Katalon\\Katalon_Studio_Engine_Windows_721\\katalonc"
            BQSA_KEY = "f9r53saz2i0kp7ybv4c3xz25lpo6hge52a60ok8ng5c"
        }

        options {
            skipDefaultCheckout(true)
            //disableConcurrentBuilds()
            buildDiscarder(logRotator(numToKeepStr: '30', artifactNumToKeepStr: '5'))
            //lock(resource: 'AndriodBuild', inversePrecedence: true)
        }

        parameters {
            choice(
                    name: 'Environment',
                    choices: "releasetest\nopstest\ndev2\nqa1\nqa2\nuat1\nuat2\nstage\nbreakfix",
                    description: 'type of environment'
            )
            choice(name: 'TestType',
                    choices: "smokeTest\nfunctionalTest\nregressionTest",
                    description: 'types of tests')
        }

        stages {
            stage('Git clone') {
                steps {
                    deleteDir()
                    script {

                        dir("${env.BRANCH_NAME}") {


                            def scmProp = checkout scm

                            git_commit = scmProp.GIT_COMMIT
                            git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
                            gitbranch = scmProp.GIT_BRANCH
                            gituri = scmProp.GIT_URL
                            testType = params.TestType
                            envName = params.Environment
                            now = new Date()
                            String time = now.format("yyyy-MM-dd-HH-mm", TimeZone.getTimeZone('PST'))
                            // For PR gituri will be NULL
                            if (gituri) {

                                appname = ParseCommonVars.getAppname(gituri)
                                compname = ParseCommonVars.getCompname(gituri)
                                jiraVersion = ParseCommonVars.getJiraVersion()
                                jiraProjectKey = ParseCommonVars.getJiraKey()
                                ZIP_TAG = time + '.zip'
                                buildVersion = "${jiraVersion}" + '.' + "${env.BUILD_ID}"
                                gitrevisionid = GitUtils.getRevisionID()
                                GitUtils.getChangelist(git_commit, git_previous_successful_commit)

                            }
                        }
                        currentBuild.description = "${params.TestType}" + '-' + "${params.Environment}"
                        currentBuild.displayName = '#' + "${buildVersion}"


                        //If workspace contains pom.xml, run Web Services test command else Katalon command
                        def workspace = pwd()
                        findFile = workspace+"//${env.BRANCH_NAME}//pom.xml"
                        exists = fileExists findFile
                        echo "Checking if pom.xml exists in file path..${exists}"

                    }
                }
            }

            stage('SmokeTest') {
                when {
                    expression { params.TestType == "smokeTest" }
                }

                steps {
                    timeout(time: 30, unit: 'MINUTES') {
                        script {
                            if (exists == true) {
                                if (gituri.toLowerCase().contains("qespvm")){
                                    echo "Running portal build"
                                    mvnbuildinfo = runTestsPortal("smoketest", params.Environment, findFile)
                                }
                                else {
                                    echo "Running web services build.."
                                    mvnbuildInfo = runTestsServices("smoketest", compname, params.Environment, findFile)
                                }

                            } else {
                                echo "Running Katalon portal build.."
                                runTests("smokeTest", compname, params.Environment)
                                //unstash 'firefoxreports'
                            }

                        }
                    }
                }
            }

            stage('FunctionalTest') {
                when {
                    expression { params.TestType == "functionalTest" }
                }
                steps {
                    timeout(time: 40, unit: 'MINUTES') {
                        script {
                            if (exists == true) {
                                if (gituri.toLowerCase().contains("qespvm")){
                                    echo "Running portal build"
                                    mvnbuildinfo = runTestsPortal("functional", params.Environment, findFile)
                                }
                                else {
                                    echo "Running web services build.."
                                    mvnbuildInfo = runTestsServices("functional", compname, params.Environment, findFile)
                                }

                            } else {
                                runTests("functionalTest", compname, params.Environment)
                                //unstash 'firefoxreports'
                            }


                        }
                    }
                }
            }

            stage('RegressionTest') {
                when {
                    expression { params.TestType == "regressionTest" }
                }
                steps {
                    timeout(time: 60, unit: 'MINUTES') {
                        script {
                            if (exists == true) {
                                if (gituri.toLowerCase().contains("qespvm")){
                                    echo "Running portal build"
                                    mvnbuildinfo = runTestsPortal("regression", params.Environment, findFile)
                                }
                                else {
                                    echo "Running web services build.."
                                    mvnbuildInfo = runTestsServices("regression", compname, params.Environment, findFile)
                                }

                            } else {
                                runTests("regressionTest", compname, params.Environment)
                                //unstash 'firefoxreports'
                            }
                        }
                    }
                }
            }
        }

        post {
            always {
                recordIssues aggregatingResults: true, enabledForFailure: true, tools: [pmdParser(pattern: '**/pmd.xml')]
                step([$class: 'JUnitResultArchiver', testResults: "**/JUnit_Report.xml", healthScaleFactor: 1.0, allowEmptyResults: true])
                //step([$class: 'JUnitResultArchiver', testResults: '**/Reports/*-*/JUnit_Report.xml', healthScaleFactor: 1.0, allowEmptyResults: true])
                //step([$class: 'JUnitResultArchiver', testResults: '**/TEST-TestSuite.xml', healthScaleFactor: 1.0, allowEmptyResults: true])
                script {
                    Utils.zip("${env.BRANCH_NAME}//Reports", "${ZIP_TAG}", ".")
                    Utils.zip("${env.BRANCH_NAME}//test-output//BSC-reports/", "${ZIP_TAG}", ".")
                    ArtifactoryUtils.UploadqeTestReports(gituri, gitbranch, jiraVersion, params.TestType, git_commit, params.Environment)
                    //GitUtils.getChangeString()
                    Utils.InsertJenkinsDB("${pipelinename}", "${compname}", "${appname}", "${ZIP_TAG}.zip", "${jiraVersion}", "${jiraProjectKey}", "${git_commit}", "${gitbranch}")

                    def testSummary = jenkinsUtils.getTestSummary()
                    echo testSummary
//                    sendNotification.notifypost("$mailRecipients")
                    archiveArtifacts "gitChangeList.txt,${ZIP_TAG}"

                }

            }
            success {
                //jiraIssueUpdater(issueSelector: [$class: 'DefaultIssueSelector'])
                echo "JOB COMPLETED SUCCESSFULLY"
            }
        }
    }
}
