#!/usr/bin/env groovy

/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */

/**
 * Send notifications based on build status string
 */

import bsc.scrmauto.jenkins.pipeline.sendNotifications

def call() {

    def sendNotifications = new sendNotifications()

    sendNotifications.notifypost()
}
