#!/usr/bin/env groovy

import bsc.scrmauto.jenkins.pipeline.*

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def ParseCommonVars = new ParseCommonVars()
    def CommonPipelineSteps = new CommonPipelineSteps()
    def Utils = new Utils()
    def GitUtils = new GitUtils()
    def Constants = new Constants()
    def ArtifactoryUtils = new ArtifactoryUtils()
    def sendNotification = new sendNotifications()
    def jiraSteps = new jiraSteps()
    def jenkinsutils = new jenkinsUtils()
    def pipelinename = this.class.getName()

    def arr = config.buildenv
    def pollscm = "${config.Pollscm}"
	def artifacttype = "${config.artifacttype}"
    def mailRecipients = "${config.mailRecipients}"


    def rhelNode = 'rhel-node'

    def gitbranch
    def gituri
    def git_commit
    def git_previous_successful_commit
    def gitrevisionid
    def appname
    def compname
    def jiraVersion
    def properties
    def ZIP_TAG
    def buildVersion
    def jiraProjectKey

    pipeline {

        triggers {
            pollSCM("${pollscm}")
        }

        agent {
            node {
                label "${rhelNode}"
            }
        }


        options {
            skipDefaultCheckout(true)
            disableConcurrentBuilds()
            buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '10'))
        }

        stages {
            stage("Git clone") {
                steps {
                    deleteDir()
                    script {
                        
                        dir("${env.BRANCH_NAME}") {
                            def scmProp = checkout scm

                            env.git_commit = scmProp.GIT_COMMIT
                            env.git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
                            env.gitbranch = scmProp.GIT_BRANCH
                            env.gituri = scmProp.GIT_URL

                            if (env.gituri) {
                                jenkinsutils.abortFirstbuild()
                                env.appname = ParseCommonVars.getAppname(env.gituri)
                                env.compname = ParseCommonVars.getCompname(env.gituri)
                                env.jiraVersion = ParseCommonVars.getJiraVersion()
                                env.jiraProjectKey = ParseCommonVars.getJiraKey()
                                env.ZIP_TAG = env.appname + '-' + env.compname + '-' + "${env.jiraVersion}" + '.' + "${env.BUILD_ID}" + '.zip'
                                env.buildVersion = "${env.jiraVersion}" + '.' + "${env.BUILD_ID}"
                                env.erm = jiraSteps.getERM(ParseCommonVars.getactualJiraVersion())
                                env.gitrevisionid = GitUtils.getRevisionID()
                                ArtifactoryUtils.CheckIsThisProdFixVersion(env.gituri,env.jiraVersion)

                            }
                        }
                        GitUtils.getChangelist()
                    }
                }
            }

            stage('Initialize') {
                steps {
                    sh """
                       echo copying ${JENKINS_ARTIFACT_TEMPLATE_ZIP}
                       cp ${JENKINS_ARTIFACT_TEMPLATE_ZIP} .
                       echo "PATH = ${PATH}"
                    """
                    script {
                        Utils.unzip("dist", "JenkinsArtifactTemplate.zip",)
                    }
					sh 'printenv | sort'
                }
            }

            stage('Build') {
                steps {
                    script {
                            CommonPipelineSteps.prebuildscript()
							Utils.copy("${env.BRANCH_NAME}", "dist/du_full", "**/*", "**/component.properties,**/Jenkinsfile,**/.git/**")
                            CommonPipelineSteps.postbuildscript()
                    }

                }
            }

            stage("Artifactory Upload") {
                
                steps {
                    script {
                        echo "${env.ZIP_TAG}"
                        Utils.zip("dist", "${env.ZIP_TAG}", ".", "**/component.properties,**/Jenkinsfile")
                        ArtifactoryUtils.Uploadartifact(env.gituri, env.gitbranch, env.jiraVersion, env.git_commit, env.ZIP_TAG, env.erm)
                        archiveArtifacts '*-*-*.zip,gitChangeList.txt'
                    }

                }
            }
        }

        post {
            always {
                script {
                    Utils.InsertJenkinsDB("${pipelinename}", "${env.compname}", "${env.appname}", "${env.ZIP_TAG}.zip", "${env.jiraVersion}", "${env.jiraProjectKey}", "${env.git_commit}", "${env.gitbranch}","${env.erm}")
                    sendNotification.notifypost("$mailRecipients")
                }

            }
            success {
                script {
                    jiraSteps.commentChangeIssueszip(env.jiraProjectKey, env.ZIP_TAG).each { jiraChange ->
                        jiraAddComment(idOrKey: jiraChange.id,
                                comment: jiraChange.comment,
                                failOnError: false,
                                site: "jira"
                        )
                    }
                    
                    echo "JOB COMPLETED SUCCESSFULLY"
                }
            }
        }
    }
}