#!/usr/bin/env groovy

/**
 * @author pdigum01
 * @Team IT-SCRM-Automation
 */

/**
 * Send notifications based on build status string
 */

import bsc.scrmauto.jenkins.pipeline.jenkinsDeployUtils

def call(String jName = "", String envName = "", String rlsVer = "", boolean hold = false) {

    def triggerDeployJob = new jenkinsDeployUtils()

    triggerDeployJob.triggerDeployJob(jName, envName, rlsVer, hold)
}
