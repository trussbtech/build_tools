#!/usr/bin/env groovy
import bsc.scrmauto.jenkins.pipeline.*

//commenteing
def runbuild(env, appVersion, gradleversion) {
    if ((env != "templete")) {
        stage("Build: ${env}") {
            echo "Running ${env} build..."
            withEnv(["POM_VERSION=${appVersion}"]) {
                withCredentials([string(credentialsId: 'blueshield_android.keystore', variable: 'KEYPWD'), string(credentialsId: 'X_IBM_Client_Id_PROD', variable: 'X_IBM_Client_Id_PROD'), string(credentialsId: 'X_IBM_Client_Secret_PROD', variable: 'X_IBM_Client_Secret_PROD'), string(credentialsId: 'ZIPPWD', variable: 'ZIPPWD')]) {
                    ansiColor('xterm') {
                        bat "CALL buildscript.bat $env $gradleversion"
                    }
                }
            }

        }

    }
}

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def ParseCommonVars = new ParseCommonVars()
    def Utils = new Utils()
    def GitUtils = new GitUtils()
    def Constants = new Constants()
    def appCenterUserAPItoken = Constants.appCenterUserAPItoken
    def NexusUtils = new NexusUtils()
    def ArtifactoryUtils = new ArtifactoryUtils()
    def sendNotification = new sendNotifications()
    def jiraSteps = new jiraSteps()
    def pipelinename = this.class.getName()

    def pollscm = "${config.Pollscm}"
    def jdkversion = "${config.jdkversion}"
    def gradleversion = "${config.gradleversion}"
    def appCenter_appName = "${config.appCenter_appName}"
    def hockey_app_file = "${config.hockey_app_file}"
    def mailRecipients = "${config.mailRecipients}"
    def appVersion = "${config.appVersion}"


    def slave = 'build-windows'

    def gitbranch
    def gituri
    def git_commit
    def git_previous_successful_commit
    def gitrevisionid
    def appname
    def compname
    def jiraVersion
    def erm
    def ZIP_TAG
    def envlist
    def buildVersion
    def jiraProjectKey


    pipeline {

        triggers {
            pollSCM("#${pollscm}")
        }

        agent {
            node {
                label "${slave}"
            }
        }

        options {
            skipDefaultCheckout(true)
            disableConcurrentBuilds()
            buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '3'))
            //lock(resource: 'AndriodBuild', inversePrecedence: true)
        }


        tools {
            jdk "${jdkversion}"
        }

        stages {
            stage('Git clone') {
                steps {
                    deleteDir()
                    script {

                        dir("${env.BRANCH_NAME}") {

                            def scmProp = checkout scm

                            git_commit = scmProp.GIT_COMMIT
                            git_previous_successful_commit = scmProp.GIT_PREVIOUS_SUCCESSFUL_COMMIT
                            gitbranch = scmProp.GIT_BRANCH
                            gituri = scmProp.GIT_URL

                            // For PR gituri will be NULL
                            if (gituri) {

                                appname = ParseCommonVars.getAppname(gituri)
                                compname = ParseCommonVars.getCompname(gituri)
                                jiraVersion = ParseCommonVars.getJiraVersion()
                                jiraProjectKey = ParseCommonVars.getJiraKey()
                                erm = jiraSteps.getERM(ParseCommonVars.getactualJiraVersion())
                                ZIP_TAG = appname + '-' + compname + '-' + "${appVersion}" + '.' + "${env.BUILD_ID}" + '.zip'
                                buildVersion = "${appVersion}" + '.' + "${env.BUILD_ID}"
                                gitrevisionid = GitUtils.getRevisionID()


                                envlist = Utils.readDir("env_config")
                            }
                        }
                        GitUtils.getChangelist()
                    }
                }
            }

            stage('Initialize') {
                steps {
                    script {

                        bat """
                            @echo off
                            java -jar %EXTERNAL_TOOLS_TRUNK%\\JenkinsMobileUtils\\JenkinsMobileUtils.jar -e %WORKSPACE%\\${
                            env.BRANCH_NAME
                        }\\env_config -t %WORKSPACE%\\${
                            env.BRANCH_NAME
                        }\\env_config\\templete\\Android\\string-data.xml -x %WORKSPACE%\\${env.BRANCH_NAME}\\env_config -o string-data.xml
                            echo sdk.dir=%ANDROID_HOME%>%WORKSPACE%\\${env.BRANCH_NAME}\\local.properties
                            """
                        Utils.getartifacttemplate()
                        dir("${env.BRANCH_NAME}") {

                            if (!gitbranch.contains("PR-")) {
                                for (int i = 0; i < envlist.length; i++) {
                                    env = "${envlist[i]}"
                                    runbuild(env, appVersion, gradleversion)

                                }
                            } else {
                                env = "stage"
                                runbuild(env, appVersion, gradleversion)
                            }

                            /*env = "release_test_webh23"
                        if (env != "templete") {
                            stage("Build: ${env}") {
                                echo "Running ${env} build..."

                                withEnv(["POM_VERSION=${jiraVersion}"]){
                                    withCredentials([string(credentialsId: 'blueshield_android.keystore', variable: 'KEYPWD'), string(credentialsId: 'X_IBM_Client_Id_PROD', variable: 'X_IBM_Client_Id_PROD'), string(credentialsId: 'X_IBM_Client_Secret_PROD', variable: 'X_IBM_Client_Secret_PROD'), string(credentialsId: 'ZIPPWD', variable: 'ZIPPWD')]) {
                                        bat "CALL buildscript.bat $env $gradleversion"
                                    }
                                }

                            }
                        }*/

                        }

                    }
                }

            }

            stage("Publish artifact") {
                when {
                    expression {
                        !gitbranch.contains("PR-")
                    }
                }
                steps {

                    parallel(
                            Artifactory: {
                                script {
                                    Utils.zip("dist", "${ZIP_TAG}", ".")
                                    //NexusUtils.Uploadartifact("${appname}", "${compname}", "${jiraVersion}", "${ZIP_TAG}")
                                    ArtifactoryUtils.Uploadartifactmobile(gituri, gitbranch, appVersion, git_commit, ZIP_TAG, erm)
                                    archiveArtifacts '*-*-*.zip,gitChangeList.txt'
                                }
                            },
                            Appcenter: {

                                script {
                                    echo "Need to add Appcenter"
                                    appCenter apiToken: appCenterUserAPItoken,
                                            appName: "${appCenter_appName}",
                                            distributionGroups: "BSC_Testers",
                                            notifyTesters: true,
                                            ownerName: 'blueshieldofcalifornia',
                                            pathToApp: "**/${hockey_app_file}",
                                            releaseNotes: ''

                                    //                                hockeyApp applications: [[apiToken          : "${appCenterUserAPItoken}",
                                    //                                                          downloadAllowed   : true,
                                    //                                                          filePath          : "**/${hockey_app_file}",
                                    //                                                          mandatory         : true,
                                    //                                                          notifyTeam        : true,
                                    //                                                          oldVersionHolder  : [numberOldVersions: '10', sortOldVersions: 'version', strategyOldVersions: 'soft'],
                                    //                                                          releaseNotesMethod: changelog(),
                                    //                                                          uploadMethod      : versionCreation(appId: "${hockey_appid}", versionCode: '')]]
                                }
                            }

                    )

                }

            }

        }

        post {
            always {
                script {
                    //GitUtils.getChangeString()
                    Utils.InsertJenkinsDB("${pipelinename}", "${compname}", "${appname}", "${ZIP_TAG}.zip", "${jiraVersion}", "${jiraProjectKey}", "${git_commit}", "${gitbranch}","${erm}")
                    sendNotification.notifypost("$mailRecipients")

                }

            }
            success {
                script {
                    //jiraSteps.commentChangeIssueszip(jiraProjectKey, ZIP_TAG)
                    jiraSteps.commentChangeIssueszip(jiraProjectKey, ZIP_TAG).each { jiraChange ->
                        jiraAddComment(idOrKey: jiraChange.id,
                                comment: jiraChange.comment,
                                failOnError: false,
                                site: "jira"
                                //auditLog: false
                        )
                    }
                    echo "JOB COMPLETED SUCCESSFULLY"
                }

            }
        }
    }
}