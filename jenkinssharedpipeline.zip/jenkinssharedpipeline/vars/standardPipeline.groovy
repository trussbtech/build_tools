#!/usr/bin/env groovy

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    node {
        // Clean workspace before doing anything
        deleteDir()

        try {
            stage('Clone') {
                sh "echo 'checkout scm ${config.svnuri}'"
                def svnuri = "${config.svnuri}"
                sh "echo 'checkout scm $svnuri'"
                checkout([$class: 'SubversionSCM', additionalCredentials: [], excludedCommitMessages: '', excludedRegions: '', excludedRevprop: '', excludedUsers: '', filterChangelog: false, ignoreDirPropChanges: false, includedRegions: '', locations: [[credentialsId: 'a24c7ac9-7f9f-4ad0-ab3a-bf49001c3241', depthOption: 'infinity', ignoreExternalsOption: true, local: './MemberPortal', remote: "${svnuri}"]], workspaceUpdater: [$class: 'UpdateUpdater']])
            }
            stage('Build') {
                sh "echo 'building ${config.projectName} ...'"
            }
            stage('Tests') {
                node('windows-node') {
                    parallel 'static': {
                        bat "echo 'shell scripts to run static tests...'"
                    },
                            'unit': {
                                bat "echo 'shell scripts to run unit tests...'"
                            },
                            'integration': {
                                bat "echo 'shell scripts to run integration tests...'"
                            }
                }
            }
            stage('Deploy') {
                sh "echo 'deploying to server ${config.serverDomain}...'"
            }
        } catch (err) {
            currentBuild.result = 'FAILED'
            throw err
        }
    }
}
